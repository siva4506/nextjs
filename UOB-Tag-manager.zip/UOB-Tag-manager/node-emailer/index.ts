import dotenv from 'dotenv';
import express, {Express, Request, Response} from "express";
import nodemailer from 'nodemailer';

dotenv.config({path: 'D:\\Harish\\UOB\\UOB-Tag-manager\\node-emailer\\.env'});

const app: Express = express();
app.use(express.json());
const port = process.env.PORT;

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST ??= 'xeragomail01.xerago.com',
    port: Number.parseInt(process.env.SMTP_PORT ??= '465'),
    secure: true,
    auth: {
        user: process.env.SMTP_USERNAME,
        pass: process.env.SMTP_PASSWORD,
    },
});

interface EmailSendRequest {
    fromName: string,
    fromEmail: string,
    toName?: string,
    toEmail: string,
    codeLifetime: number,
    otpCode: string,
}

app.get('/', (req: Request, res: Response) => {
    res.send('Express + TypeScript Server');
});

app.post('/send-mail', async (req: Request, res: Response) => {
    console.log(`request: ${JSON.stringify(req.body)}`);
    const input = req.body as EmailSendRequest;
    try {
        const info = await transporter.sendMail({
            from: `"${input.fromName}" <${input.fromEmail}>`, // sender address
            to: input.toEmail, // list of receivers
            subject: "Hello ✔", // Subject line
            text: "Hello world?", // plain text body
            html: `<b>Hello? Your OTP is ${input.otpCode}</b>`, // html body
        });
        console.log("Message sent: %s", info.messageId);
    } catch (err) {
        console.error('some shit bro', err);
        res.json({status: 'error', error: err}).status(500);
    }
    res.json({status: 'sent'}).status(200);
});

app.listen(port, () => {
    console.log(`node mailer running on http://localhost:${port}`);
});
