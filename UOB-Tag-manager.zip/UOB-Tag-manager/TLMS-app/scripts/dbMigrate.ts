import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db } from "@/libs/DB";

async function main() {
  await migrate(db, { migrationsFolder: "./drizzle" });

  console.log("migrations complete");
  process.exit(0);
}

main().catch((e) => {
  console.error("Migration failed");
  console.log(e);
  process.exit(1);
});
