import { db } from '@/libs/DB';
import { Campaign, Channel, Client, Product, Tag, User } from '@/models/Schema';

async function main() {
  await db.delete(Tag);
  await db.delete(Campaign);
  await db.delete(Product);
  await db.delete(Channel);
  await db.delete(User);
  await db.delete(Client);
}

main().catch((e) => {
  // eslint-disable-next-line no-console
  console.log(e);
  process.exit(1);
});
