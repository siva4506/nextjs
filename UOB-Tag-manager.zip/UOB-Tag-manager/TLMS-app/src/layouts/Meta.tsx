import type { ReactNode } from 'react';
import React from 'react';

import Header from '@/components/Header';
import NavBar from '@/components/NavBar';

type IMetaProps = {
  children: ReactNode;
};

const Meta = (props: IMetaProps) => (
  <div>
    <Header />
    <div className="mt-[65px] grid grid-cols-12">
      <div className=" col-span-2">
        <NavBar />
      </div>
      <main className="col-span-10">{props.children}</main>
    </div>
  </div>
);

export { Meta };
