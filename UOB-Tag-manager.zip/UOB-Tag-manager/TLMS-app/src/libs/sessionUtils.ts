'use server';

// eslint-disable-next-line import/no-extraneous-dependencies
import { serialize } from 'cookie';
import { cookies, headers } from 'next/headers';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
// eslint-disable-next-line import/no-extraneous-dependencies
import {
  CollectingResponse,
  PreParsedRequest,
} from 'supertokens-node/framework/custom';
import type {
  SessionContainer,
  VerifySessionOptions,
} from 'supertokens-node/recipe/session';
// eslint-disable-next-line import/no-extraneous-dependencies
import Session from 'supertokens-node/recipe/session';
import type { HTTPMethod } from 'supertokens-node/types';

import { ensureSuperTokensInit } from '@/config/backend';

ensureSuperTokensInit();

export const runtime = 'nodejs';

export async function getSSRSession(
  req?: NextRequest,
  options?: VerifySessionOptions
): Promise<{
  session: SessionContainer | undefined;
  hasToken: boolean;
  hasInvalidClaims: boolean;
  baseResponse: CollectingResponse;
  nextResponse?: NextResponse;
}> {
  const query =
    req !== undefined
      ? Object.fromEntries(new URL(req.url).searchParams.entries())
      : {};
  const parsedCookies: Record<string, string> = Object.fromEntries(
    (req !== undefined ? req.cookies : cookies())
      .getAll()
      .map((cookie) => [cookie.name, cookie.value])
  );
  const baseRequest = new PreParsedRequest({
    method: req !== undefined ? (req.method as HTTPMethod) : 'get',
    url: req !== undefined ? req.url : '',
    query,
    headers: req !== undefined ? req.headers : headers(),
    cookies: parsedCookies,
    getFormBody: () => req!.formData(),
    getJSONBody: () => req!.json(),
  });

  const baseResponse = new CollectingResponse();

  try {
    const session = await Session.getSession(
      baseRequest,
      baseResponse,
      options
    );
    return {
      session,
      hasInvalidClaims: false,
      hasToken: session !== undefined,
      baseResponse,
    };
  } catch (err) {
    if (Session.Error.isErrorFromSuperTokens(err)) {
      return {
        hasToken: err.type !== Session.Error.UNAUTHORISED,
        hasInvalidClaims: err.type === Session.Error.INVALID_CLAIMS,
        session: undefined,
        baseResponse,
        nextResponse: new NextResponse('Authentication required', {
          status: err.type === Session.Error.INVALID_CLAIMS ? 403 : 401,
        }),
      };
    }
    throw err;
  }
}

export async function withSession(
  request: NextRequest,
  handler: (session: SessionContainer | undefined) => Promise<NextResponse>,
  options?: VerifySessionOptions
) {
  const { session, nextResponse, baseResponse } = await getSSRSession(
    request,
    options
  );
  if (nextResponse) {
    console.log('redirect to auth');
    const url = request.nextUrl.clone();
    url.pathname = '/auth';
    return NextResponse.redirect(url);
  }

  const userResponse = await handler(session);

  let didAddCookies = false;
  let didAddHeaders = false;

  for (const respCookie of baseResponse.cookies) {
    didAddCookies = true;
    userResponse.headers.append(
      'Set-Cookie',
      serialize(respCookie.key, respCookie.value, {
        domain: respCookie.domain,
        expires: new Date(respCookie.expires),
        httpOnly: respCookie.httpOnly,
        path: respCookie.path,
        sameSite: respCookie.sameSite,
        secure: respCookie.secure,
      })
    );
  }

  baseResponse.headers.forEach((value, key) => {
    didAddHeaders = true;
    userResponse.headers.set(key, value);
  });

  if (didAddCookies || didAddHeaders) {
    if (!userResponse.headers.has('Cache-Control')) {
      // This is needed for production deployments with Vercel
      userResponse.headers.set(
        'Cache-Control',
        'no-cache, no-store, max-age=0, must-revalidate'
      );
    }
  }

  return userResponse;
}
