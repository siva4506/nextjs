import { drizzle } from 'drizzle-orm/node-postgres';
// @ts-ignore
// noinspection TypeScriptCheckImport
import { Pool } from 'pg';

import * as schema from '../models/Schema';

const pool = new Pool({
  host: '127.0.0.1',
  port: 5432,
  user: 'postgres',
  password: 'password',
  database: 'postgres',
});

export const db = drizzle(pool, {
  schema,
});
