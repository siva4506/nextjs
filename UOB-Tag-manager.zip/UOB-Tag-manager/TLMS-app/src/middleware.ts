import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import { withSession } from '@/libs/sessionUtils';

export async function middleware(request: NextRequest) {
  // eslint-disable-next-line no-console
  console.log(`middleware: req: ${JSON.stringify(request.nextUrl)}`);

  if (
    request.nextUrl.pathname.startsWith('/auth') ||
    request.nextUrl.pathname.startsWith('/api/auth') ||
    (request.nextUrl.pathname === '/api/user' && request.method === 'POST')
  ) {
    return NextResponse.next();
  }

  return withSession(
    request,
    async (session: { getUserId: () => any } | undefined) => {
      if (session === undefined) {
        return NextResponse.redirect('/auth');
      }

      return NextResponse.next({
        headers: {
          [SUPER_TOKEN_HEADER]: session.getUserId(),
        },
      });
    }
  );
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
