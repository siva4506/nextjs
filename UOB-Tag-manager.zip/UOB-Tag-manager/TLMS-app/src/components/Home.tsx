import React from 'react';

import Dashboard from './Dashboard';

const Home = () => {
  return (
    // <div className="flex w-full">
    //   <div className=" mx-4 w-2/12">
    //     <NavBar />
    //   </div>
    //   <div className="z-50 w-10/12 overflow-auto">
    //     <Dashboard />
    //   </div>
    //   {/* <div className="w-3/12">
    //     <Notification />
    //   </div> */}
    // </div>
    <div className="w-full">
      <Dashboard />
    </div>
  );
};

export default Home;
