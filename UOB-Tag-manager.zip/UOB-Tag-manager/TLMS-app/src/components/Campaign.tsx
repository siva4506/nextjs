import React from 'react';

const Campaign = () => {
  return <div />;
};

export default Campaign;
