import { headers } from 'next/headers';
import React from 'react';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import Tag from '@/components/Tag';
import type { TState } from '@/models/Schema';
import { getAllStates } from '@/services/stateServices';
import { getTagsForClient } from '@/services/tagService';

import Card from './Card';
import Header from './Header';

const Dashboard = async () => {
  const states: TState[] = await getAllStates();
  const tags = await getTagsForClient(headers().get(SUPER_TOKEN_HEADER)!);
  console.log('tags', tags);
  return (
    <div className="">
      <Header />
      <div className="">
        <h1 className="pb-6 text-xl font-bold ">Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {states.map(async (state) => {
            return (
              <Card
                key={state.id}
                title={state.name ?? 'NOT Named'}
                state={state.id}
              />
            );
          })}
        </div>
      </div>
      {/* <div className="border-t-2"> */}
      <div className="">
        <Tag params={{ state: undefined }} tags={tags} />
      </div>
    </div>
  );
};
export default Dashboard;
