// 'use client';

// import React, { useState } from 'react';

// const TestForm = () => {
//   const [formSections, setFormSections] = useState([
//     // Initial form section
//     { url: '', textarea: '', select: '', input: '', file: null },
//   ]);

//   const [eventSections, setEventSections] = useState([
//     // Initial form section
//     { select: '', input: '', file: null },
//   ]);

//   const addEventSection = (e) => {
//     e.preventDefault();
//     setEventSections([...eventSections, { select: '', input: '', file: null }]);
//   };

//   const addSection = (e) => {
//     e.preventDefault();
//     setFormSections([
//       ...formSections,
//       { url: '', textarea: '', select: '', input: '', file: null },
//     ]);
//   };
//   // @ts-ignore
//   const handleInputChange = (index, field, value) => {
//     const newSections = [...formSections];
//     // @ts-ignore
//     newSections[index][field] = value;
//     setFormSections(newSections);
//   };
//   // @ts-ignore
//   const handleEventInputChange = (index, field, value) => {
//     const newSections = [...eventSections];
//     // @ts-ignore
//     newSections[index][field] = value;
//     setFormSections(newSections);
//   };
//   return (
//     <div>
//       <form>
//         <label>
//           Tag Name: <input type="text" className="border" />
//         </label>
//         <br />
//         <label>
//           Campaign: <input type="text" className="border" />
//         </label>
//         <br />
//         <label>
//           Segment:
//           <select name="option" id="1" className="border">
//             <option value="">option 1</option>
//             <option value="">option 2</option>
//           </select>
//         </label>
//         <br />
//         <label>
//           Business:
//           <select name="option" id="1" className="border">
//             <option value="">option 1</option>
//             <option value="">option 2</option>
//           </select>
//         </label>
//         <br />
//         <label>
//           Product:
//           <select name="option" id="1" className="border">
//             <option value="">option 1</option>
//             <option value="">option 2</option>
//           </select>
//         </label>
//         <br />
//         <label>
//           Media:
//           <select name="option" id="1" className="border">
//             <option value="">option 1</option>
//             <option value="">option 2</option>
//           </select>
//         </label>
//         <br />
//         <label>
//           Tag Type:
//           <select name="option" id="1" className="border">
//             <option value="">option 1</option>
//             <option value="">option 2</option>
//           </select>
//         </label>
//         <br />
//         <label>
//           Container Tag:
//           <textarea name="" id="" className="border" />
//         </label>
//         <br />
//         <label>
//           Media Tag:
//           <textarea name="" id="" className="border" />
//         </label>
//         <br />
//         <label>
//           Start Date:
//           <input type="date" className="border" />
//         </label>
//         <br />
//         <label>
//           Expiry Date:
//           <input type="date" className="border" />
//         </label>
//         <br />
//         {formSections.map((section, index) => (
//           <div key={index}>
//             <label>URL:</label>
//             <input
//               type="text"
//               className="border"
//               value={section.url}
//               onChange={(e) => handleInputChange(index, 'url', e.target.value)}
//             />
//             <br />
//             <textarea
//               name=""
//               id=""
//               className="border"
//               value={section.textarea}
//               onChange={(e) =>
//                 handleInputChange(index, 'textarea', e.target.value)
//               }
//             />
//             <br />
//             <select
//               name="option"
//               id="1"
//               className="border"
//               value={section.select}
//               onChange={(e) =>
//                 handleInputChange(index, 'select', e.target.value)
//               }
//             >
//               <option value="">option 1</option>
//               <option value="">option 2</option>
//             </select>
//             <input
//               type="text"
//               className="border"
//               value={section.input}
//               onChange={(e) =>
//                 handleInputChange(index, 'input', e.target.value)
//               }
//             />
//             <input
//               type="file"
//               onChange={(e) =>
//                 handleInputChange(index, 'file', e.target.files[0])
//               }
//             />
//             <button onClick={addSection}>+</button>
//             <br />
//             <br />
//           </div>
//         ))}
//       </form>
//     </div>
//   );
// };

// export default TestForm;
