import Link from 'next/link';
import React from 'react';

import type { TagTableView } from '@/services/tagService';
import { getTagsByStateId } from '@/services/tagService';

interface CardProps {
  title: string;
  state: number;
  // bg: string;
}

const Card = async (props: CardProps) => {
  const view: TagTableView[] = await getTagsByStateId(props.state);
  return (
    <Link href={`/tag/?state=${props.state}`}>
      <div>
        <div className="flex flex-col gap-6 rounded-2xl bg-white p-4">
          <p className="font-medium text-black">{props.title}</p>
          <p className="text-right text-3xl font-semibold text-black">
            {view.length}
          </p>
        </div>
      </div>
    </Link>
  );
};

export default Card;
