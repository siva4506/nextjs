'use client';

import Link from 'next/link';
import React from 'react';
import { BiArrowBack, BiEditAlt } from 'react-icons/bi';

import type { TagData } from '@/common/types';
import Tooltip from '@/components/ToolTip';

import Journal from './Journal';

const TagDetails = (param: { tagData: TagData }) => {
  // const showData = () => {
  //   console.log(param.tagData);
  // };
  return (
    <div>
      <div className="flex items-center gap-2 border-b py-2">
        <Link href="/" className="pl-6 font-semibold">
          <BiArrowBack size={30} />
        </Link>
        <h1 className="text-base font-semibold">Tag Details</h1>
      </div>
      <div className="relative m-2 w-6/12 p-4 pr-20">
        <Tooltip message="Edit">
          <Link href={`/tag/edit/${param.tagData.id}`}>
            <BiEditAlt size={40} className="absolute right-0 top-0 p-2" />
          </Link>
        </Tooltip>
        <div className="m-4">
          <div className="flex-col gap-2 py-2">
            <h1 className="mb-2 mr-52 border-b border-black pb-2 font-semibold">
              Campaign Name
            </h1>
            <p className="">{param.tagData.campaign.name}</p>
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Channel
            </h1>
            <p>{param.tagData.channel.name}</p>
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Media Tag
            </h1>
            <p>{param.tagData.mediaTag}</p>
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Production Date
            </h1>
            <p>{param.tagData.productionDate?.toString().split('T')[0]}</p>
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Expiry Date
            </h1>
            <p>{param.tagData.expiryDate?.toString().split('T')[0]}</p>
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Product
            </h1>
            {param.tagData.tagProductMap.map((tagProduct) => (
              <p key={tagProduct.product.id}>{tagProduct.product.name}</p>
            ))}
          </div>
          <div className="flex-col gap-2 py-4">
            <h1 className="mb-2 mr-52 border-b border-black pb-1 font-semibold">
              Page
            </h1>
            {param.tagData.pages.map((page) => (
              <p key={page.pageData.id}>{page.pageData.pageUrl}</p>
            ))}
          </div>
          {param.tagData.additionalInfo ?? (
            <div className="flex gap-2 py-2">
              <h1 className="font-bold">Additional Information:</h1>
              <p>{param.tagData.additionalInfo}</p>
            </div>
          )}
        </div>
      </div>
      {/* <button onClick={showData}>Show</button> */}
      <Journal journalData={param.tagData.tracker.journalEntries} />
    </div>
  );
};

export default TagDetails;
