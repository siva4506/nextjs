import Image from 'next/image';
import React from 'react';

const Intro = () => {
  return (
    <div className="bg-gray-100 pl-12 pt-72">
      <div>
        <Image
          alt="logo"
          src="/images/LOGO.png"
          width={100}
          height={100}
          className="mb-6"
        />
        <div className="w-8/12">
          <h1 className="mb-4 text-2xl font-semibold">
            Tag Managing Application
          </h1>
          <p className="text-sm">
            Xerago TMA is a powerful and versatile Tag Managing Application
            designed to streamline your tag management processes and enhance
            your digital marketing efforts.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Intro;
