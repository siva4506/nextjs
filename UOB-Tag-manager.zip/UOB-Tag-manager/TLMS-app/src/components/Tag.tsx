'use client';

import React from 'react';

import type { TagTableView } from '@/services/tagService';

import TagTable from './TagTable';

const Tag = ({
  shouldIncludeHeader = true,
  params,
  tags,
}: {
  shouldIncludeHeader?: boolean | undefined;
  params: { state: number | undefined };
  tags: TagTableView[];
}) => {
  return (
    <div>
      {shouldIncludeHeader && (
        <>
          {/* <div className="flex items-center gap-2 border-b-2 py-2">
            <h1 className="px-4 py-1 font-semibold ">Tag Details</h1>
          </div> */}
          <h1 className="pb-6 pt-8 text-xl font-bold ">Tag Details</h1>
          <div className="mb-8 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300 "
            >
              Live Tag
            </button>
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300 "
            >
              In Queue Tag
            </button>
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300  "
            >
              Tag Deduplication
            </button>
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300 "
            >
              UAT Deployment
            </button>
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300  "
            >
              Deployment to PROD
            </button>
            <button
              type="button"
              className="rounded-xl bg-gray-200 p-3 text-sm font-semibold text-black  duration-300 ease-in-out hover:bg-gray-300 "
            >
              Nearby Expiry
            </button>
          </div>
        </>
      )}
      <TagTable state={params.state} tagData={tags} />
    </div>
  );
};

export default Tag;
