import type { Meta, StoryObj } from '@storybook/react';

import TagTable from '../TagTable';

const meta: Meta<typeof TagTable> = {
  component: TagTable,
};

export default meta;
type Story = StoryObj<typeof TagTable>;

export const Primary: Story = {
  render: () => (
    <TagTable
      state={1}
      tagData={[
        {
          id: 1,
          createdOn: new Date(),
          updatedON: new Date(),
          mediaTag: 'media Tag',
          productionDate: new Date(),
          expiryDate: new Date(),
          additionalInfo: 'add info',
          ofCampaign: 1,
          forChannel: 1,
          channel: { name: 'Channel#1' },
          campaign: { name: 'Campaign#1' },
        },
      ]}
    />
  ),
};
