import type { Meta, StoryObj } from '@storybook/react';

import NewRequest from '../NewRequest';

const meta: Meta<typeof NewRequest> = {
  component: NewRequest,
};

export default meta;
type Story = StoryObj<typeof NewRequest>;

export const Primary: Story = {
  render: () => <NewRequest />,
};
