// 'use client';

// import 'bootstrap/dist/css/bootstrap.min.css';

// import Head from 'next/head';
// import React, { useEffect } from 'react';

// const TestCard = () => {
//   useEffect(() => {
//     require('bootstrap/dist/js/bootstrap.bundle.min.js');
//   }, []);
//   return (
//     <div>
//       <Head>
//         <script
//           src="https://kit.fontawesome.com/42d5adcbca.js"
//           crossorigin="anonymous"
//         />
//         <meta
//           name="viewport"
//           content="width=device-width, initial-scale=1, shrink-to-fit=no"
//         />
//         <link
//           href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=optional"
//           rel="stylesheet"
//         />
//       </Head>

//       <div className="row">
//         <div className="col-lg-3 col-md-6 col-12">
//           <div className="card mb-4">
//             <div className="card-body p-3">
//               <div className="row">
//                 <div className="col-8">
//                   <div className="numbers">
//                     <p className="text-uppercase font-weight-bold mb-0 text-sm">
//                       Today's Money
//                     </p>
//                     <h5 className="font-weight-bolder">$53,000</h5>
//                     <p className="mb-0">
//                       <span className="text-success font-weight-bolder text-sm">
//                         +55%
//                       </span>
//                       since yesterday
//                     </p>
//                   </div>
//                 </div>
//                 <div className="col-4 text-end">
//                   <div className="icon icon-shape bg-gradient-primary shadow-primary rounded-circle text-center">
//                     <i
//                       className="ni ni-money-coins text-lg opacity-10"
//                       aria-hidden="true"
//                     />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//         <div className="col-lg-3 col-md-6 col-2">
//           <div className="card mb-4">
//             <div className="card-body p-3">
//               <div className="row">
//                 <div className="col-4">
//                   <div className="numbers">
//                     <p className="text-uppercase font-weight-bold mb-0 text-sm">
//                       Today's Users
//                     </p>
//                     <h5 className="font-weight-bolder">2,300</h5>
//                     <p className="mb-0">
//                       <span className="text-success font-weight-bolder text-sm">
//                         +3%
//                       </span>
//                       since last week
//                     </p>
//                   </div>
//                 </div>
//                 <div className="col-4 text-end">
//                   <div className="icon icon-shape bg-gradient-danger shadow-danger rounded-circle text-center">
//                     <i
//                       className="ni ni-world text-lg opacity-10"
//                       aria-hidden="true"
//                     />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//         <div className="col-lg-3 col-md-6 col-12">
//           <div className="card mb-4">
//             <div className="card-body p-3">
//               <div className="row">
//                 <div className="col-8">
//                   <div className="numbers">
//                     <p className="text-uppercase font-weight-bold mb-0 text-sm">
//                       New Clients
//                     </p>
//                     <h5 className="font-weight-bolder">+3,462</h5>
//                     <p className="mb-0">
//                       <span className="text-danger font-weight-bolder text-sm">
//                         -2%
//                       </span>
//                       since last quarter
//                     </p>
//                   </div>
//                 </div>
//                 <div className="col-4 text-end">
//                   <div className="icon icon-shape bg-gradient-success shadow-success rounded-circle text-center">
//                     <i
//                       className="ni ni-paper-diploma text-lg opacity-10"
//                       aria-hidden="true"
//                     />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//         <div className="col-lg-3 col-md-6 col-12">
//           <div className="card mb-4">
//             <div className="card-body p-3">
//               <div className="row">
//                 <div className="col-8">
//                   <div className="numbers">
//                     <p className="text-uppercase font-weight-bold mb-0 text-sm">
//                       Sales
//                     </p>
//                     <h5 className="font-weight-bolder">$103,430</h5>
//                     <p className="mb-0">
//                       <span className="text-success font-weight-bolder text-sm">
//                         +5%
//                       </span>
//                       than last month
//                     </p>
//                   </div>
//                 </div>
//                 <div className="col-4 text-end">
//                   <div className="icon icon-shape bg-gradient-warning shadow-warning rounded-circle text-center">
//                     <i
//                       className="ni ni-cart text-lg opacity-10"
//                       aria-hidden="true"
//                     />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default TestCard;
