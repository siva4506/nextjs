'use client';

import { useState } from 'react';

const Login = () => {
  const [loginCta, setLoginCta] = useState(false);
  const handleCta = () => {
    setLoginCta(true);
  };
  return (
    <div className="pb-16">
      {/* <div className="rounded-full  p-1 top-0 right-0">
        <RiCustomerServiceLine size={16} />
      </div> */}
      <div className="relative w-8/12 pl-12 pt-72">
        <h1 className="mb-8 text-2xl font-semibold">Login</h1>
        <div>
          {/* eslint-disable-next-line jsx-a11y/label-has-associated-control */}
          <label htmlFor="email" className="mb-2 block">
            Email or User ID
          </label>
          <input id="email" type="email" className="w-full border p-2 " />
          <p className="absolute right-0 mt-1">Resend OTP</p>
        </div>
        {/* eslint-disable-next-line tailwindcss/no-custom-classname */}
        <div className={`${loginCta ? 'display' : 'hidden'}`}>
          {/* eslint-disable-next-line jsx-a11y/label-has-associated-control */}
          <label htmlFor="otp" className="mb-2 mt-6 block">
            OTP
          </label>
          <input type="text" className="w-full border p-2" id="otp" />
        </div>
        <button
          type="submit"
          onClick={handleCta}
          className="mt-6 bg-black px-10 py-2 text-sm text-white"
        >
          {loginCta ? 'Login' : 'Send OTP'}
        </button>
      </div>
    </div>
  );
};

export default Login;
