/* eslint-disable jsx-a11y/label-has-associated-control */

'use client';

import { ErrorMessage } from '@hookform/error-message';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { BiArrowBack } from 'react-icons/bi';

import { updateTagAction } from '@/app/action/tagActions';
import type {
  EditChannelConfig,
  EditTagRequest,
  TagData,
} from '@/common/types';
import type { TChannel, TProduct } from '@/models/Schema';

type EditTagType = {
  campaignName: string;
  channelConfig: EditChannelConfig;
  actionToApply: number | null | undefined;
};

const EditTagForm = (param: { tagData: TagData }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<EditTagType>({
    defaultValues: {
      campaignName: param.tagData.campaign.name,
      actionToApply: undefined,
      channelConfig: {
        ofChannel: param.tagData.forChannel,
        mediaTag: param.tagData.mediaTag,
        additionalInfo: param.tagData.additionalInfo,
        productionDate: param.tagData.productionDate,
        products: param.tagData.tagProductMap.map(
          (tagProduct) => tagProduct.product.id
        ),
        pageUrl: param.tagData.pages.map((page) => page.pageData.pageUrl),
      },
    },
    mode: 'onBlur',
    reValidateMode: 'onBlur',
  });
  const [channels, setChannels] = useState<TChannel[]>([]);
  const [products, setProducts] = useState<TProduct[]>([]);
  const [tagProducts, setTagProducts] = useState<number[]>([]);

  useEffect(() => {
    async function getProducts() {
      const response = await fetch('/api/product', { cache: 'no-cache' });
      // eslint-disable-next-line @typescript-eslint/no-shadow
      const products = await response.json();
      setProducts(products.products);
      setTagProducts(
        param.tagData.tagProductMap.map((tagProduct) => tagProduct.product.id)
      );
    }

    async function getChannels() {
      const response = await fetch('/api/channel', { cache: 'no-cache' });
      // eslint-disable-next-line @typescript-eslint/no-shadow
      const channels = await response.json();
      setChannels(channels.channels);
    }

    // noinspection JSIgnoredPromiseFromCall
    getProducts();
    // noinspection JSIgnoredPromiseFromCall
    getChannels();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // @ts-ignore
  function updateTag(e) {
    e.preventDefault();
    handleSubmit(
      async (data) => {
        // eslint-disable-next-line no-console
        console.log(data);

        const body: EditTagRequest = {
          tagId: param.tagData.id,
          channelConfig: data.channelConfig,
          campaignName: data.campaignName,
          actionToApply: data.actionToApply,
        };

        await updateTagAction(body);
      },
      // eslint-disable-next-line no-console
      (data) => console.log(data)
    )();
  }

  return (
    <div className="">
      <div className="flex items-center gap-2 border-b-2 py-2">
        <Link href="/" className="pl-6 font-semibold">
          <BiArrowBack size={25} />
        </Link>
        <h1 className="text-base font-semibold">Edit Request Form</h1>
      </div>
      <form className="flex w-5/12 flex-col  justify-center py-10 pl-8">
        <label className="font-medium">Actions</label>
        <select
          className="mb-6 mt-2 w-full border p-1 text-sm"
          {...register(`actionToApply` as const, {
            required: 'This is required.',
            valueAsNumber: true,
            min: {
              value: 1,
              message: 'please Choose A action',
            },
          })}
        >
          <option key="None" value={undefined}>
            --None--
          </option>
          {param.tagData.currentState.applicableActions.map(
            (applicableAction) => (
              <option
                key={applicableAction.action.name}
                value={applicableAction.action.id}
              >
                {applicableAction.action.name}
              </option>
            )
          )}
        </select>
        <label htmlFor="campaign_name" className="block text-sm font-medium">
          Campaign Name
        </label>
        <div>
          <input
            type="text"
            id="campaign_name"
            className="mb-6 mt-2 w-full border p-1 text-sm"
            {...register(`campaignName` as const, {
              required: 'this field is required',
            })}
          />
          <ErrorMessage
            errors={errors}
            name="campaignName"
            render={({ message }) => <p>{message}</p>}
          />
        </div>

        <h1 className="pb-4 font-semibold">Channels Configuration</h1>
        <label className="block text-sm font-medium">Choose Channel</label>
        <div>
          <select
            className="mb-6 mt-2 w-full border p-1 text-sm"
            {...register(`channelConfig.ofChannel` as const, {
              required: 'This is required.',
              valueAsNumber: true,
              min: {
                value: 1,
                message: 'please Choose A Channel',
              },
            })}
          >
            {channels.map((channel) => (
              <option
                key={channel.id}
                value={channel.id}
                selected={channel.id === param.tagData.channel.id}
              >
                {channel.name}
              </option>
            ))}
          </select>
          <ErrorMessage
            errors={errors}
            name="channelConfig.ofChannel"
            render={({ message }) => <p>{message}</p>}
          />
        </div>

        <label className="block text-sm font-medium">Choose products</label>
        <div>
          <select
            multiple
            className="mb-6 mt-2 w-full border p-1 text-sm"
            {...register(`channelConfig.products` as const, {
              required: 'at least one Product is required',
              validate: {
                nonNull: (v) => typeof v !== null && v?.length !== 0,
              },
            })}
          >
            {products.map((product) => (
              <option
                key={product.id}
                value={product.id}
                selected={tagProducts.includes(product.id)}
              >
                {product.name}
              </option>
            ))}
          </select>
          <ErrorMessage
            errors={errors}
            name="channelConfig.product"
            render={({ message }) => <p>{message}</p>}
          />
        </div>

        <label className="block text-sm font-medium">
          {/* eslint-disable-next-line react/no-unescaped-entities */}
          Expected Media Tag's
        </label>
        <div>
          <input
            type="text"
            className="mb-6 mt-2 w-full border p-1 text-sm"
            defaultValue={param.tagData.mediaTag ?? ''}
            {...register(`channelConfig.mediaTag` as const, {
              valueAsNumber: false,
              required: 'this field is required',
            })}
          />
          <ErrorMessage
            errors={errors}
            name="channelConfig.mediaTag"
            render={({ message }) => <p>{message}</p>}
          />
        </div>
        <label className="block text-sm font-medium">Page urls</label>
        <div className="mb-6 mt-2 ">
          {param.tagData.pages.map((page, index) => (
            <ul key={page.pageData.id}>
              <input
                type="text"
                defaultValue={page.pageData.pageUrl}
                id={page.pageData.id.toString()}
                key={page.pageData.id}
                className="mb-3 w-full border p-1 text-sm"
                {...register(`channelConfig.pageUrl.${index}` as const, {
                  valueAsNumber: false,
                  required: true,
                })}
              />
              <ErrorMessage
                errors={errors}
                name="channelConfig.pageUrl"
                render={({ message }) => <p>{message}</p>}
              />
            </ul>
          ))}
        </div>
        <label className="block text-sm font-medium">Production Date</label>
        <div>
          <input
            type="date"
            className="mb-6 w-full border p-1 text-sm"
            // @ts-ignore
            value={param.tagData.productionDate?.toISOString().split('T')[0]}
            {...register(`channelConfig.productionDate` as const, {
              valueAsDate: true,
              required: true,
              validate: {
                notNow: (v) => v !== new Date(),
              },
            })}
            disabled
          />
          <ErrorMessage
            errors={errors}
            name="channelConfig.productionDate"
            render={({ message }) => <p>{message}</p>}
          />
        </div>
        <label className="block text-sm font-medium">Expiry Date</label>
        <div>
          <input
            type="date"
            className="mb-6 mt-2 w-full border p-1 text-sm"
            // @ts-ignore
            value={param.tagData.expiryDate?.toISOString().split('T')[0]}
            {...register(`channelConfig.expiryDate` as const, {
              valueAsDate: true,
              required: true,
              validate: {
                notNow: (v) => v !== new Date(),
              },
            })}
          />
          <ErrorMessage
            errors={errors}
            name="channelConfig.expiryDate"
            render={({ message }) => <p>{message}</p>}
          />
        </div>
        <label className="block text-sm font-medium">Additional Info</label>
        <div>
          <input
            type="text"
            className="mb-6 mt-2 w-full border p-1 text-sm"
            defaultValue={param.tagData.expiryDate?.toString().split('T')[0]}
            {...register(`channelConfig.additionalInfo` as const)}
          />
        </div>
        <label className="mb-2 block text-sm font-medium">Comments</label>
        <textarea
          placeholder="Enter your comments here..."
          className="border border-gray-500 p-2"
        />
        <button
          type="submit"
          className="m-4 mx-auto w-3/12 border-2 border-zinc-700 bg-slate-200 p-1"
          onClick={(e) => updateTag(e)}
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default EditTagForm;
