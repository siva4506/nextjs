import React from 'react';

const Footer = () => {
  return (
    <div className=" border-t-2 py-3">
      <h1 className="text-center">
        Copyright &copy; 2023, Xerago. All rights reserved.
      </h1>
    </div>
  );
};

export default Footer;
