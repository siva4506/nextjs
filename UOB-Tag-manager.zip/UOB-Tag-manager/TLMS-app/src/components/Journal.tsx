import React from 'react';

import type { JournalOfTag } from '@/common/types';

const Journal = async (props: { journalData: JournalOfTag[] }) => {
  return (
    <div>
      {props.journalData.map((journal) => (
        <ul key={journal.id}>
          <div className="border-black-400 m-3 border p-2">
            <p>Comments:</p>
            <p key={`journal${journal.id}-comment`} className="pb-2">
              {journal.comment}
            </p>
            <h1>
              Created on
              <span key={`journal${journal.id}-createdOn`} className="pl-2">
                {typeof journal.createdOn === 'string'
                  ? journal.createdOn
                  : journal.createdOn?.toDateString().split('T')[0]}
              </span>
            </h1>
            <div className="flex gap-1">
              <h1>Updated from </h1>
              <span key={`journal${journal.id}-fromState`}>
                {journal.fromState}
              </span>
              <p>to</p>
              <span key={`journal${journal.id}-toState`}>
                {journal.toState}
              </span>
            </div>
          </div>
        </ul>
      ))}
    </div>
  );
};

export default Journal;
