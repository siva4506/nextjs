/* eslint-disable no-console,jsx-a11y/label-has-associated-control */
// noinspection JSUnusedLocalSymbols

'use client';

import { ErrorMessage } from '@hookform/error-message';
import Link from 'next/link';
import React, { useEffect, useRef, useState } from 'react';
import { useFieldArray, useForm } from 'react-hook-form';
import { AiOutlinePlusCircle } from 'react-icons/ai';
import { BiArrowBack } from 'react-icons/bi';

import { createTagAction } from '@/app/action/tagActions';
import type { NewTagRequest } from '@/common/types';
import type { TChannel, TProduct } from '@/models/Schema';

// TODO - use react-form-hook instead of html forms directly
type ChannelConfig = {
  ofChannel: number;
  product: number[];
  mediaTag: string;
  pageUrl: string[];
  productionDate: Date;
  expiryDate: Date;
  additionalInfo: string;
};

type FormValues = {
  channelConfig: ChannelConfig[];
};

// noinspection JSIgnoredPromiseFromCall
const NewRequest = () => {
  const [channels, setChannels] = useState<TChannel[]>([]);
  const [products, setProducts] = useState<TProduct[]>([]);
  const [campaignName, setCampaignName] = useState('');
  const [campaignsLikeName, setCampaignsLikeName] = useState<
    { id: number; name: string }[]
  >([]);
  const [campaignNameSuggestionSelected, setCampaignNameSuggestionSelected] =
    useState<boolean>(false);
  const campaignNameSuggestionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const getData = setTimeout(() => {
      // debugger
      if (
        !campaignName ||
        campaignName.length < 3 ||
        campaignNameSuggestionSelected
      ) {
        return;
      }
      fetch('/api/campaign/search-by-name', {
        cache: 'no-cache',
        method: 'POST',
        body: JSON.stringify({ campaignName }),
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      })
        .then((res) => res.json())
        .then((data) => setCampaignsLikeName(data.campaigns))
        .then((_) => {
          if (
            campaignNameSuggestionsRef.current &&
            campaignNameSuggestionSelected
          )
            campaignNameSuggestionsRef.current.style.display = 'block';
        });
    }, 1000);

    return () => clearTimeout(getData);
  }, [campaignName, campaignNameSuggestionSelected]);

  useEffect(() => {
    async function getProducts() {
      const response = await fetch('/api/product', { cache: 'no-cache' });
      // eslint-disable-next-line @typescript-eslint/no-shadow
      const products = await response.json();
      console.log(products.products);
      setProducts(products.products);
    }

    async function getChannels() {
      const response = await fetch('/api/channel', { cache: 'no-cache' });
      // eslint-disable-next-line @typescript-eslint/no-shadow
      const channels = await response.json();
      console.log(channels);
      setChannels(channels.channels);
    }

    // noinspection JSIgnoredPromiseFromCall
    getProducts();
    // noinspection JSIgnoredPromiseFromCall
    getChannels();
  }, []);

  const createTag = async (
    channelConfig: ChannelConfig[],
    isDraft: boolean
  ) => {
    const body: NewTagRequest = {
      campaignName,
      channelConfig,
      isDraft,
    };
    await createTagAction(body);
  };

  const {
    register,
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    defaultValues: {
      channelConfig: [{ mediaTag: '', pageUrl: [''], additionalInfo: '' }],
    },
    mode: 'onBlur',
    reValidateMode: 'onBlur',
  });

  const { fields, append, remove } = useFieldArray({
    name: 'channelConfig',
    control,
  });

  const [pageUrlFieldsCounts, setPageUrlFieldsCounts] = useState(
    fields.map(() => 1)
  );

  function campaignNameChosenFromSuggestion(
    _campaignId: number,
    _campaignName: string
  ) {
    console.log(`campaignId: ${_campaignId}, campaignName: ${_campaignName}`);
    setCampaignName(_campaignName);
    if (campaignNameSuggestionsRef.current)
      campaignNameSuggestionsRef.current.style.display = 'none';
    setCampaignNameSuggestionSelected(true);
  }

  function saveTagAsDraft() {
    handleSubmit(async (data) => {
      console.log('saveTagAsDraft');
      await createTag(data.channelConfig, true);
    })();
  }

  function saveTagAndSendAsRequest() {
    handleSubmit(async (data) => {
      console.log('saveTagAndSendAsRequest');
      await createTag(data.channelConfig, false);
    })();
  }

  return (
    <div>
      <div className="flex items-center gap-2 border-b-2 py-2">
        <Link href="/request" className="pl-6 font-semibold">
          <BiArrowBack size={25} />
        </Link>
        <h1 className="text-base font-semibold ">New Request Form</h1>
      </div>
      <div className="relative w-5/12 p-10">
        <div className="flex justify-between ">
          <h1 className="items-center pb-8 text-lg font-semibold text-gray-800">
            Request Details
          </h1>
          {/* <button
            type="button"
            className="text-base font-normal text-emerald-500"
          >
            Reset Form
          </button> */}
        </div>
        {/* <label htmlFor="campaign_name" className="mb-2 block text-sm">
          Campaign Name
        </label>
        <input
          id="campaign_name"
          type="text"
          placeholder=""
          className="mb-4 w-full border p-1 text-sm outline-none"
          // {...register('campaign_name', { required: 'This is required' })}
        /> */}

        <ErrorMessage
          errors={errors}
          name="campaign_name"
          render={({ message }) => (
            <p className=" pb-4 text-red-500">{message}</p>
          )}
        />

        <form
          className="flex flex-col justify-center"
          // onSubmit={handleSubmit((data) => onSubmit(data))}
        >
          <label
            htmlFor="campaign_name"
            className="mb-2 block text-sm font-medium text-gray-700"
          >
            Campaign Name
          </label>
          <div className="relative">
            <input
              id="campaign_name"
              name="campaign_name"
              type="text"
              placeholder="Enter Campaign Name"
              className=" w-full border p-1 text-sm outline-none"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
              onKeyDown={(_) => setCampaignNameSuggestionSelected(false)}
            />
            <div
              className="absolute w-full"
              style={{ top: '50px' }}
              ref={campaignNameSuggestionsRef}
            >
              <ul>
                {campaignsLikeName &&
                  campaignsLikeName.map((campaign) => (
                    // eslint-disable-next-line jsx-a11y/click-events-have-key-events,jsx-a11y/no-noninteractive-element-interactions
                    <li
                      key={campaign.id}
                      onClick={() =>
                        campaignNameChosenFromSuggestion(
                          campaign.id,
                          campaign.name
                        )
                      }
                    >
                      {campaign.name}
                    </li>
                  ))}
              </ul>
            </div>
          </div>
          {fields.map((field, index) => {
            return (
              <>
                {fields.length > 1 && index !== 0 && <hr className="mb-5" />}
                <ul key={field.id}>
                  <div className="flex justify-between pb-4 pt-6">
                    <h1 className="text-md  font-semibold">
                      Channels Configuration
                    </h1>
                    <div className="flex flex-row items-center justify-center">
                      <button
                        type="button"
                        className="mr-2 flex  flex-row font-normal text-emerald-500"
                        onClick={() => {
                          setValue(`channelConfig.${index}`, {
                            ofChannel: 0,
                            product: [],
                            mediaTag: '',
                            pageUrl: [''],
                            additionalInfo: '',
                            productionDate: new Date(),
                            expiryDate: new Date(),
                          });
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth="1.5"
                          stroke="currentColor"
                          className="h-6 w-6"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"
                          />
                        </svg>
                        <span> Reset</span>
                      </button>
                      {fields.length > 1 && (
                        <button
                          type="button"
                          onClick={() => remove(index)}
                          className="text-red-500"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth="1.5"
                            stroke="currentColor"
                            className="h-6 w-6"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                            />
                          </svg>
                        </button>
                      )}
                    </div>
                  </div>
                  <label className="mb-2 block text-sm font-medium">
                    Choose Channel
                  </label>
                  <select
                    className="w-full overflow-auto border p-1 text-sm outline-none "
                    placeholder=""
                    {...register(`channelConfig.${index}.ofChannel` as const, {
                      required: 'This is required.',
                      valueAsNumber: true,
                      min: {
                        value: 1,
                        message: 'Please choose a channel',
                      },
                    })}
                  >
                    <option value={0}>None</option>
                    {channels.map((channel) => (
                      <option key={channel.id} value={channel.id}>
                        {channel.name}
                      </option>
                    ))}
                  </select>

                  <ErrorMessage
                    errors={errors}
                    name={`channelConfig.${index}.ofChannel`}
                    render={({ message }) => (
                      <p className="text-sm text-red-500">{message}</p>
                    )}
                  />
                  <label className="mb-2 mt-6 block text-sm font-medium">
                    Product
                  </label>
                  <select
                    multiple
                    className="w-full overflow-auto border p-1 text-sm outline-none"
                    {...register(`channelConfig.${index}.product` as const, {
                      valueAsNumber: true,
                      required: 'At least one Product is required',
                      // validate: {
                      //   nonNull: (v) => typeof v !== null && v?.length !== 0,
                      // },
                    })}
                  >
                    {products.map((product) => (
                      <option key={product.id} value={product.id}>
                        {product.name}
                      </option>
                    ))}
                  </select>
                  <ErrorMessage
                    errors={errors}
                    name={`channelConfig.${index}.product`}
                    render={({ message }) => (
                      <p className="text-sm text-red-500">{message}</p>
                    )}
                  />

                  <label className="mb-2 mt-6 block text-sm font-medium">
                    {/* eslint-disable-next-line react/no-unescaped-entities */}
                    Expected Media Tag's
                  </label>
                  <textarea
                    rows={5}
                    cols={65}
                    className="w-full border p-1 text-sm outline-none"
                    placeholder="Enter Expected Media Tag"
                    {...register(`channelConfig.${index}.mediaTag` as const, {
                      valueAsNumber: false,
                      required: 'This field is required',
                    })}
                  />
                  <ErrorMessage
                    errors={errors}
                    name={`channelConfig.${index}.mediaTag` as const}
                    render={({ message }) => (
                      <p className="text-sm text-red-500">{message}</p>
                    )}
                  />

                  <label className="mb-2 mt-6 block text-sm font-medium">
                    Page URL to be Tagged
                  </label>
                  {Array.from({ length: pageUrlFieldsCounts[index] || 1 }).map(
                    (_, urlIndex) => (
                      // eslint-disable-next-line react/no-array-index-key
                      <div key={urlIndex}>
                        <input
                          type="text"
                          className="mb-3 w-full border p-1 text-sm outline-none"
                          placeholder="Enter Page URL to be Tagged"
                          {...register(
                            `channelConfig.${index}.pageUrl.${urlIndex}` as const,
                            {
                              valueAsNumber: false,
                              required: true,
                            }
                          )}
                        />
                      </div>
                    )
                  )}
                  <button
                    type="button"
                    className="mb-6 border p-1 text-sm"
                    onClick={(e) => {
                      e.preventDefault();
                      // Create a copy of the counts array and update the count for the current index
                      const newCounts = [...pageUrlFieldsCounts];
                      newCounts[index] = (newCounts[index] || 0) + 1;
                      setPageUrlFieldsCounts(newCounts);
                    }}
                  >
                    <AiOutlinePlusCircle />
                  </button>
                  <label className="mb-2 block text-sm font-medium">
                    Production Date
                  </label>
                  <input
                    type="date"
                    className="mb-6 w-full border p-1 text-sm outline-none"
                    {...register(
                      `channelConfig.${index}.productionDate` as const,
                      {
                        valueAsDate: true,
                        required: true,
                        validate: {
                          notNow: (v) => v !== new Date(),
                        },
                      }
                    )}
                  />
                  <label className="mb-2 block text-sm font-medium">
                    Expiry Date
                  </label>
                  <input
                    type="date"
                    className="mb-6 w-full border p-1 text-sm outline-none"
                    {...register(`channelConfig.${index}.expiryDate` as const, {
                      valueAsDate: true,
                      required: true,
                      validate: {
                        notNow: (v) => v !== new Date(),
                      },
                    })}
                  />
                  <label className="mb-2 block text-sm font-medium">
                    Additional Information
                  </label>
                  <input
                    type="text"
                    placeholder="Enter Additional Information"
                    className="mb-8 w-full border p-1 text-sm outline-none"
                  />
                </ul>
              </>
            );
          })}
          <button
            type="button"
            className="relative mb-8 w-[40%] self-center rounded-full border-2 border-dashed border-gray-700 p-2"
            onClick={(e) => {
              e.preventDefault();
              append({
                ofChannel: 0,
                product: [],
                mediaTag: '',
                pageUrl: [''],
                additionalInfo: '',
                productionDate: new Date(),
                expiryDate: new Date(),
              });
            }}
          >
            <div className="mr-2 flex items-center justify-center gap-2">
              <AiOutlinePlusCircle />
              <h1 className="text-sm font-semibold">New Channel</h1>
            </div>
          </button>
        </form>
        <div className="flex justify-center gap-3">
          <button
            type="submit"
            className="w-24 rounded bg-gradient-to-r from-green-400  to-blue-500 px-5 py-1 text-sm font-semibold text-gray-100 duration-300 ease-in-out hover:from-green-500  hover:to-blue-600 "
            onClick={saveTagAsDraft}
          >
            Save
          </button>
          <button
            className="w-24 rounded bg-gradient-to-r from-green-400  to-blue-500 px-5 py-1 text-sm font-semibold text-gray-100  duration-300 ease-in-out hover:from-green-500  hover:to-blue-600"
            type="submit"
            onClick={saveTagAndSendAsRequest}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewRequest;
