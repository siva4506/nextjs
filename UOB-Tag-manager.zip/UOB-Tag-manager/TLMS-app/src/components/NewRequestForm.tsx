'use client';

import { Button, Select, TextArea, TextField } from '@radix-ui/themes';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

import type { TChannel, TProduct } from '@/models/Schema';

export const newRequestFormSchema = z.object({
  campaignName: z.string().min(5),
  channel: z.string().min(1),
  products: z.array(z.string().min(1)).optional(),
  mediaTag: z.string().min(1),
  pageUrls: z.array(z.string().min(5)).min(1),
  productionDate: z.date().min(new Date()),
  expiryDate: z.date().min(new Date()),
  additionalInfo: z.string().optional(),
});

export type NewRequestFormFields = z.infer<typeof newRequestFormSchema>;

export type NewRequestFormProps = {
  products: TProduct[];
  channels: TChannel[];
};

const NewRequestForm = ({
  products = [],
  channels = [],
}: NewRequestFormProps) => {
  const router = useRouter();
  const { register, handleSubmit } = useForm<NewRequestFormFields>();

  return (
    <form
      onSubmit={handleSubmit((data) => {
        // eslint-disable-next-line no-console
        console.log(data);

        router.push('/');
      })}
      className="max-w-xl space-y-3"
    >
      <TextField.Root>
        <TextField.Input
          placeholder="Campaign #42"
          {...register('campaignName')}
        />
      </TextField.Root>
      <Select.Root>
        <Select.Trigger placeholder="Select Channel" />
        <Select.Content>
          {channels.map((c) => (
            <Select.Item key={c.id} value={c.id.toString()}>
              {c.name}
            </Select.Item>
          ))}
        </Select.Content>
      </Select.Root>
      <Select.Root>
        <Select.Trigger placeholder="Select Product(s)" />
        <Select.Content>
          {products.map((p) => (
            <Select.Item key={p.id} value={p.id.toString()}>
              {p.name}
            </Select.Item>
          ))}
        </Select.Content>
      </Select.Root>
      <TextArea placeholder="Media Tag" {...register('mediaTag')} />
      <Button>Save</Button>
      <Button>Send</Button>
    </form>
  );
};

export default NewRequestForm;
