'use client';

import { getTheme } from '@table-library/react-table-library/baseline';
import { CompactTable } from '@table-library/react-table-library/compact';
import { useRowSelect } from '@table-library/react-table-library/select';
import { useTheme } from '@table-library/react-table-library/theme';
import Link from 'next/link';
import * as React from 'react';
import { AiFillEye } from 'react-icons/ai';
import { BiEditAlt } from 'react-icons/bi';

import type { TagTableView } from '@/services/tagService';

// eslint-disable-next-line no-console
const Component = (params: {
  state: number | undefined;
  tagData: TagTableView[];
}) => {
  const nodes = params.tagData.map((td) => ({
    ...td,
    productionDate:
      typeof td.productionDate === 'string'
        ? td.productionDate
        : td.productionDate?.toDateString(),
    expiryDate:
      typeof td.expiryDate === 'string'
        ? td.expiryDate
        : td.expiryDate?.toDateString(),
  }));
  const data = { nodes };

  // console.log(typeof nodes[0]?.productionDate);
  const theme = useTheme([
    getTheme(),
    {
      Table: `
        --data-table-library_grid-template-columns:  44px repeat(5, minmax(0, 1fr));
      `,
      HeaderRow: `
      
      `,
      HeaderCell: `
   margin-bottom: 8px;
    align-text: left;
    font: normal;
    font-size: 15px;
    font-weight: 500;
    color:  #4b4b4b;
  `,
      Row: `
     background-color: rgb(209 250 229);
    
      `,
      BaseRow: `
       margin-bottom: 8px;
      `,
      BaseCell: `
      margin-bottom: 4px;
      font-size: 14px;
      `,
    },
  ]);

  const COLUMNS = [
    {
      label: 'Task ID',
      renderCell: (item1: TagTableView) => item1.id,
      select: true,
    },

    {
      label: 'Campaign',
      renderCell: (item: TagTableView) => item.campaign.name,
    },
    { label: 'Channel', renderCell: (item: TagTableView) => item.channel.name },
    {
      label: 'Start Date',
      renderCell: (item: TagTableView) => item.productionDate,
    },
    {
      label: 'End Date',
      renderCell: (item: TagTableView) => item.expiryDate,
    },
    {
      label: 'Edit',
      renderCell: (item: TagTableView) => (
        // <button
        //   type="button"
        //   // eslint-disable-next-line no-alert
        //   onClick={() => alert('delete node')}
        //   className="text-green-500"
        // >
        //   <Link href="/tag/edit/${item.id}">Edit</Link>
        // </button>
        <Link href={`/tag/edit/${item.id}`}>
          <BiEditAlt size={25} />
        </Link>
      ),
    },
    {
      label: 'Detail',
      renderCell: (item: TagTableView) => (
        <Link href={`/tagDetail/${item.id}`}>
          <AiFillEye size={25} />
        </Link>
      ),
    },
  ];
  const select = useRowSelect(data, {
    // eslint-disable-next-line no-use-before-define,@typescript-eslint/no-use-before-define
    onChange: onSelectChange,
  });

  // @ts-ignore
  function onSelectChange(action, state) {
    // eslint-disable-next-line no-console
    console.log(action, state);
  }

  return (
    <div className="overflow-x-auto">
      <CompactTable
        columns={COLUMNS}
        data={data}
        theme={theme}
        layout={{ custom: true }}
        select={select}
      />
    </div>
  );
};

export default Component;
