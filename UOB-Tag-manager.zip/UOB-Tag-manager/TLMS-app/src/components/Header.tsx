/* eslint-disable jsx-a11y/click-events-have-key-events */

'use client';

import React, { useState } from 'react';
import { AiFillBell } from 'react-icons/ai';
import { BiSolidSearchAlt2, BiSolidUser } from 'react-icons/bi';
import { RiCustomerServiceFill } from 'react-icons/ri';
import { signOut } from 'supertokens-auth-react/recipe/passwordless';

import Notification from './Notification';

const Header = () => {
  const [notificationFlag, setNotificationFlag] = useState<boolean>(false);
  // const [isNav, setIsNav] = useState<boolean>(false);
  // const displayNav = () => {
  //   setIsNav(!isNav);
  // };
  // // const [isToggle, setIsToggle] = useState<boolean>(false);
  // const dispatch = useDispatch();

  // const handleToggle = () => {
  //   dispatch(toggleSidebar());
  // };

  return (
    <>
      {/* <div className="fixed top-0 z-50 flex w-full items-center justify-between bg-white py-3 shadow-md">
        <Image
          alt="logo"
          src="/images/LOGO.png"
          width={100}
          height={100}
          className="ml-4 "
        /> */}
      {/* TODO use NextJS Image tag instead */}
      {/* //className="block md:hidden" */}
      <div className="mb-12 mr-4 mt-6 flex justify-end gap-4">
        {/* <button onClick={displayNav}>click</button> */}

        <div className=" rounded-full bg-gray-200 p-1.5">
          <BiSolidUser
            size={20}
            onClick={async () => {
              await signOut();
            }}
          />
        </div>
        <div className=" rounded-full bg-gray-200 p-1.5">
          <BiSolidSearchAlt2 size={20} />
        </div>
        <div className=" rounded-full bg-gray-200 p-1.5">
          <RiCustomerServiceFill size={20} />
        </div>
        {/* eslint-disable-next-line jsx-a11y/interactive-supports-focus */}
        <div
          role="button"
          className=" rounded-full bg-gray-200 p-1.5"
          onClick={(_) => setNotificationFlag(!notificationFlag)}
        >
          <AiFillBell size={20} />
        </div>
      </div>
      {/* </div> */}
      {notificationFlag === true && (
        <>
          {/* eslint-disable-next-line jsx-a11y/interactive-supports-focus, jsx-a11y/control-has-associated-label */}
          <div
            role="button"
            className="fixed left-0 top-0 z-[8] h-full w-full bg-black/30 backdrop-blur-sm "
            onClick={(_) => setNotificationFlag(!notificationFlag)}
          />
          <Notification />
        </>
      )}
    </>
  );
};

export default Header;
