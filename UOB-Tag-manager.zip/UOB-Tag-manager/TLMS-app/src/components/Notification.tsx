import React from 'react';

const Notification = () => {
  return (
    <div className="absolute right-0 top-[66px] z-[9] h-[calc(100%_-_66px)] w-[300px] border-b-2 bg-white transition delay-150 ease-in-out">
      <h1 className=" p-2 font-semibold">Notification</h1>
    </div>
  );
};

export default Notification;
