import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import { User } from '@/models/Schema';

export const getClientId = async (superTokenId: string): Promise<number> => {
  const user = await db.query.User.findFirst({
    where: eq(User.superTokenId, superTokenId),
  });
  if (!user) {
    throw new Error(`User matching token ${superTokenId} not found`);
  }

  return user.ofClient;
};
