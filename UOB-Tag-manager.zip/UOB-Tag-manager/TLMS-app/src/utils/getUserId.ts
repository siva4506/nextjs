import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import { User } from '@/models/Schema';

export const getUserId = async (superTokenId: string): Promise<number> => {
  const user = await db.query.User.findFirst({
    where: eq(User.superTokenId, superTokenId),
  });

  if (!user) {
    throw new Error(`User with superTokenId: ${superTokenId} not found`);
  }

  return user.id;
};
