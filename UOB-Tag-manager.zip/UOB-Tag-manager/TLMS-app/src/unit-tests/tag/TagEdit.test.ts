// eslint-disable-next-line import/no-extraneous-dependencies
import { afterAll, beforeAll } from '@jest/globals';
import { eq, inArray } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TTag } from '@/models/Schema';
import { Journal, Page, Tag, TagsToPages } from '@/models/Schema';
import { createTagInternal, editTag } from '@/services/tagService';

describe('edit tag test', () => {
  let tagId: number | undefined;
  const expiryDate = new Date();
  expiryDate.setUTCFullYear(2023, 12, 25);
  const channelConfig = {
    ofChannel: 1,
    mediaTag: 'test media tag',
    pageUrl: ['https://test.com/page-1', 'https://test.com/page-2'],
    product: [1, 2],
    productionDate: new Date(),
    expiryDate,
    additionalInfo: 'additional info',
  };
  const campaignName = 'Test campaign #1';
  const tagCreationRequest = {
    campaignName,
    isDraft: true,
    channelConfig: [channelConfig],
  };

  beforeAll(async () => {
    const tag: TTag[] = await createTagInternal(tagCreationRequest, 2, 2);
    if (!tag || !tag[0]) {
      throw new Error('cannot create the test tag');
    }
    if (tag && tag[0]) tagId = tag[0].id;
  });

  afterAll(async () => {
    if (tagId) {
      const pagesInTag = await db.query.TagsToPages.findMany({
        where: eq(TagsToPages.tag, tagId),
      });
      await db.delete(TagsToPages).where(eq(TagsToPages.tag, tagId));
      await db.delete(Page).where(
        inArray(
          Page.id,
          pagesInTag.map((ttp) => ttp.page)
        )
      );
      await db.delete(Tag).where(eq(Tag.id, tagId));
    }
  });

  // eslint-disable-next-line jest/expect-expect
  test('change campaign', async () => {
    const newCampaignName = 'Test Campaign #2';
    await editTag(
      {
        tagId: tagId!,
        channelConfig,
        campaignName: newCampaignName,
      },
      'a8a1676c-42ef-42b0-a989-3e2fa2ec66e2'
    );
    const tag = await db.query.Tag.findFirst({
      where: eq(Tag.id, tagId!),
      with: {
        campaign: true,
        channel: true,
        pages: {
          with: {
            pageData: true,
          },
        },
        tagProductMap: {
          with: {
            product: true,
          },
        },
        currentState: true,
      },
    });
    expect(tag?.campaign.name).toBe(newCampaignName);
    const journals = await db.query.Journal.findMany({
      where: eq(Journal.ofTracker, tag?.id!),
    });
    expect(journals).toBeTruthy();
    expect(journals.length).toBe(1);
    expect(journals[0]?.metaData).toBeTruthy();
    // eslint-disable-next-line no-console
    console.log(
      `journals[0]?.metaData: ${JSON.stringify(journals[0]?.metaData)}`
    );
  });

  test('assignees change on state changes', async () => {
    const tag = await db.query.Tag.findFirst({
      where: eq(Tag.id, tagId!),
      with: {
        currentState: true,
        tracker: true,
      },
    });
    expect(tag?.currentState?.id).toBe(1);
    expect(tag?.tracker?.assignedToClient).toBe(2);

    await editTag(
      {
        tagId: tagId!,
        channelConfig,
        campaignName,
        actionToApply: 2,
      },
      'a8a1676c-42ef-42b0-a989-3e2fa2ec66e2'
    );
    const tagPostSendRequestAction = await db.query.Tag.findFirst({
      where: eq(Tag.id, tagId!),
      with: {
        currentState: true,
        tracker: true,
      },
    });
    expect(tagPostSendRequestAction?.currentState?.id).toBe(2);
    expect(tagPostSendRequestAction?.tracker?.assignedToClient).toBe(1);

    await editTag(
      {
        tagId: tagId!,
        channelConfig,
        campaignName,
        actionToApply: 3,
      },
      'a8a1676c-42ef-42b0-a989-3e2fa2ec66e2'
    );
    const tagPostWIP = await db.query.Tag.findFirst({
      where: eq(Tag.id, tagId!),
      with: {
        currentState: true,
        tracker: true,
      },
    });
    expect(tagPostWIP?.currentState?.id).toBe(3);
    expect(tagPostWIP?.tracker?.assignedToClient).toBe(1);

    await editTag(
      {
        tagId: tagId!,
        channelConfig,
        campaignName,
        actionToApply: 4,
      },
      'a8a1676c-42ef-42b0-a989-3e2fa2ec66e2'
    );
    const tagPostProductionPush = await db.query.Tag.findFirst({
      where: eq(Tag.id, tagId!),
      with: {
        currentState: true,
        tracker: true,
      },
    });
    expect(tagPostProductionPush?.currentState?.id).toBe(4);
    expect(tagPostProductionPush?.tracker?.assignedToClient).toBe(2);
  });
});
