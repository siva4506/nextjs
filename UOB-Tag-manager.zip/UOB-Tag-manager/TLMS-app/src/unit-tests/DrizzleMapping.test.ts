/**
 * @jest-environment node
 */
/* eslint-disable no-console */
// eslint-disable-next-line import/no-extraneous-dependencies
// import { beforeAll } from '@jest/globals';

import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import { Action, TrackerType } from '@/models/Schema';
// import type { TState } from '@/models/Schema';
// import { Action, State, StateActionMap } from '@/models/Schema';

describe('test workflow orm mappings', () => {
  // beforeAll(() => {
  //   return db
  //     .insert(State)
  //     .values({ name: 'test-in-q' })
  //     .returning()
  //     .then((states: TState[]) => {
  //       if (!states || !states[0]) {
  //         throw new Error('error in creating test state');
  //       }
  //       return db
  //         .insert(Action)
  //         .values({
  //           name: 'test-start',
  //           nextState: states[0].id,
  //         })
  //         .returning()
  //         .then((actions) => [states[0], actions[0]]);
  //     })
  //     .then(([state, action]) => {
  //       console.log(`state: ${JSON.stringify(state)}`);
  //       console.log(`action: ${JSON.stringify(action)}`);
  //       return db
  //         .insert(StateActionMap)
  //         .values({
  //           action: action!.id,
  //           state: state!.id,
  //         })
  //         .returning();
  //     });
  // });

  test('query applicable actions from a state', async () => {
    const stateWithApplicableActions = await db.query.State.findMany({
      with: {
        applicableActions: {
          with: {
            action: true,
          },
        },
      },
    });
    stateWithApplicableActions.forEach((state) => {
      console.log(`state id: ${state.id}`);
      console.log(`state name: ${state.name}`);
      state.applicableActions.forEach((applicableAction) => {
        console.log(`++ action id: ${applicableAction.action.id}`);
        console.log(`++ action name: ${applicableAction.action.name}`);
        console.log(
          `++ action next state: ${applicableAction.action.nextState}`
        );
      });
    });

    expect(stateWithApplicableActions).toBeTruthy();
  });
});

test('get default tracker type along with starting state', async () => {
  const trackerType = await db.query.TrackerType.findFirst({
    where: eq(TrackerType.name, 'default'),
    with: {
      workflow: {
        with: {
          startingState: true,
        },
      },
    },
  });
  expect(trackerType).toBeTruthy();
  expect(trackerType!.workflow.startingState.id).toBe(1);
  console.log(`trackerType: ${JSON.stringify(trackerType)}`);
});

test('get next state id from an action', async () => {
  const sendRequestAction = await db.query.Action.findFirst({
    where: eq(Action.name, 'send-request'),
    with: {
      nextState: {
        columns: {
          id: true,
        },
      },
    },
  });
  console.log(`sendRequestAction: ${JSON.stringify(sendRequestAction)}`);
  expect(sendRequestAction).toBeTruthy();
  expect(sendRequestAction!.nextState.id).toBe(2);
});
