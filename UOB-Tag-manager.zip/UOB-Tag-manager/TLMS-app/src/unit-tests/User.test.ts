import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import { User } from '@/models/Schema';
import { createUser } from '@/services/userService';

test('create a test user', async () => {
  const user = await createUser(
    'testuser@uob.com',
    '014a492d-6079-4991-a24b-85c800fe2ae2'
  );
  console.log(`user: ${JSON.stringify(user)}`);
  expect(user).toBeTruthy();
  // @ts-ignore
  await db.delete(User).where(eq(User.id, user[0].id));
});
