// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { eq, inArray } from 'drizzle-orm';

import type {
  EditTagRequest,
  FieldChange,
  JournalMetaData,
  NewTagRequest,
  TagData,
} from '@/common/types';
import { db } from '@/libs/DB';
import type { TNewPage, TTag } from '@/models/Schema';
import {
  Action,
  Channel,
  Journal,
  State,
  Tag,
  tagProductMap,
  Tracker,
} from '@/models/Schema';
import {
  createPageToBeTagged,
  updatePagesMappedToTag,
} from '@/services/pageService';
import { createTracker } from '@/services/trackerService';
import { getUserAndClientId } from '@/services/userService';
import { getClientId } from '@/utils/getClientId';
import { getUserId } from '@/utils/getUserId';

import { createCampaign, getCampaignByName } from './campaignService';

export const createNewTag = async (
  newTags: {
    ofCampaign: number;
    forChannel: number;
    mediaTag: string;
    productionDate: Date;
    expiryDate: Date;
    additionalInfo: string;
    products: number[];
    pagesUrls: string[];
  }[],
  createdBy: number,
  clientId: number,
  isDraft: boolean
): Promise<TTag[]> => {
  const createdTags: TTag[] = [];
  // eslint-disable-next-line no-plusplus,prettier/prettier
  for (let i = 0; i < newTags.length; i++) {  // NOSONAR
    const newTag = newTags[i];
    // eslint-disable-next-line no-await-in-loop
    const tracker = await createTracker(isDraft, clientId);
    // @ts-ignore
    // eslint-disable-next-line no-await-in-loop
    const createdTagArr = await db
      .insert(Tag)
      .values({
        ...newTag,
        tracker: tracker.id,
        currentState: tracker.currentState,
        ofClient: clientId,
        createdBy,
      })
      .returning();
    // eslint-disable-next-line prettier/prettier
    if (createdTagArr && createdTagArr[0]) {  // NOSONAR
      const createdTag = createdTagArr[0];
      createdTags.push(createdTag);

      // eslint-disable-next-line no-await-in-loop
      await createPageToBeTagged(
        newTag!.pagesUrls.map((p) => {
          return { pageUrl: p };
        }),
        createdTag
      );

      // eslint-disable-next-line no-await-in-loop
      await db.insert(tagProductMap).values(
        newTag!.products.map((productId) => {
          return { tagID: createdTag.id, productId };
        })
      );
    } else {
      // eslint-disable-next-line no-console
      console.warn(`some issue in creating tag with req: ${newTag}`);
    }
  }

  return createdTags;
};

export type TagTableView = {
  id: number;
  createdOn: Date | null;
  updatedON: Date | null;
  mediaTag: string | null;
  productionDate: Date | string | null;
  expiryDate: Date | string | null;
  additionalInfo: string | null;
  ofCampaign: number;
  forChannel: number;
  channel: { name: string };
  campaign: { name: string };
};
export const findAllTags = async (superTokenId: string) => {
  const { clientId } = await getUserAndClientId(superTokenId);
  // eslint-disable-next-line no-console
  console.log(`clientId: ${clientId}`);
  if (clientId === 1) {
    const trackersUnderXerago = await db.query.Tracker.findMany({
      where: eq(Tracker.assignedToClient, clientId),
      columns: { id: true },
    });

    if (!trackersUnderXerago || trackersUnderXerago.length <= 0) {
      return [];
    }

    return db.query.Tag.findMany({
      where: inArray(
        Tag.tracker,
        trackersUnderXerago.map((t) => t.id)
      ),
      with: {
        campaign: {
          columns: {
            name: true,
          },
        },
        channel: {
          columns: {
            name: true,
          },
        },
      },
    }).then((res) => res as unknown as TagTableView[]);
  }

  return db.query.Tag.findMany({
    where: eq(Tag.ofClient, clientId),
    with: {
      campaign: {
        columns: {
          name: true,
        },
      },
      channel: {
        columns: {
          name: true,
        },
      },
    },
  }).then((res) => res as unknown as TagTableView[]);
};

const getCampaignIdOfExistingCampaignOrPostCreation = async (
  campaignName: string,
  clientId: number,
  userId: number
) => {
  const campaignEntries = await getCampaignByName(campaignName);
  if (!campaignEntries) {
    const newCampaign = await createCampaign([
      {
        ofClient: clientId,
        name: campaignName,
        createdBy: userId,
      },
    ]);
    if (newCampaign[0]) {
      return newCampaign[0].id;
    }
    throw new Error('could not create new campaign');
  } else {
    return campaignEntries.id;
  }
};

export async function createTagInternal(
  tagRequest: NewTagRequest,
  clientId: number,
  userId: number
): Promise<TTag[]> {
  const campaignId = await getCampaignIdOfExistingCampaignOrPostCreation(
    tagRequest.campaignName,
    clientId,
    userId
  );
  const newTags = tagRequest.channelConfig.map((request) => ({
    ofCampaign: campaignId,
    forChannel: request.ofChannel,
    mediaTag: request.mediaTag,
    productionDate: new Date(request.productionDate),
    expiryDate: new Date(request.expiryDate),
    additionalInfo: request.additionalInfo,
    products: request.product,
    pagesUrls: request.pageUrl,
  }));

  return createNewTag(newTags, userId, clientId, tagRequest.isDraft).catch(
    (e) => {
      throw new Error(e);
    }
  );
}

export const createTagUsingForm = async (
  tagRequest: NewTagRequest,
  superTokenId: string
): Promise<TTag[]> => {
  const clientId = await getClientId(superTokenId);
  const userId = await getUserId(superTokenId);
  // noinspection UnnecessaryLocalVariableJS
  const createdTag = await createTagInternal(tagRequest, clientId, userId);
  return createdTag;
};

export const findTagById = async (tagId: number): Promise<TagData> => {
  return db.query.Tag.findFirst({
    where: eq(Tag.id, tagId),
    with: {
      pages: {
        with: {
          pageData: {
            columns: {
              pageUrl: true,
              id: true,
            },
          },
        },
      },
      campaign: {
        columns: {
          id: true,
          name: true,
        },
      },
      channel: {
        columns: {
          id: true,
          name: true,
        },
      },
      currentState: {
        with: {
          applicableActions: {
            with: {
              action: {
                columns: {
                  id: true,
                  name: true,
                },
                with: {
                  nextState: {
                    columns: {
                      id: true,
                      name: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
      tracker: {
        columns: {
          currentState: true,
        },
        with: {
          journalEntries: true,
        },
      },
      tagProductMap: {
        with: {
          product: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      },
    },
  })
    .then((res) => res as unknown as TagData)
    .catch((err) => {
      throw new Error(err);
    });
};

async function updateState(
  tagId: number,
  actionToApplyId: number | undefined | null,
  clientId: number
) {
  if (!actionToApplyId) return;

  const tagOri = await db.query.Tag.findFirst({
    where: eq(Tag.id, tagId),
    columns: { currentState: true },
  });
  const fromState = tagOri!.currentState;

  const actionToApply = await db.query.Action.findFirst({
    where: eq(Action.id, actionToApplyId),
    with: {
      nextState: {
        columns: {
          id: true,
          showToClient: true,
        },
      },
    },
  });
  if (!actionToApply) {
    // eslint-disable-next-line no-console
    console.warn('actionToApply not found');
    return;
  }
  // eslint-disable-next-line no-console
  console.log(`actionToApply: ${JSON.stringify(actionToApply)}`);

  const tracker = await db.query.Tracker.findFirst({
    where: eq(Tracker.id, tagId),
  });
  if (!tracker) {
    throw new Error(`tracker for tagId: ${tagId} not found`);
  }
  const applicableActions = await db.query.State.findFirst({
    where: eq(State.id, tracker.currentState),
    with: {
      applicableActions: true,
    },
  }).then((ap) => ap!.applicableActions);
  if (!applicableActions.map((a) => a.action).includes(actionToApply.id)) {
    // eslint-disable-next-line no-console
    console.warn(
      `next action not valid, actionToApply: ${
        actionToApply.id
      }, applicableActions: ${JSON.stringify(
        applicableActions.map((x) => x.action)
      )}`
    );
    return;
  }
  await db
    .update(Tracker)
    .set({
      currentState: actionToApply.nextState.id,
      assignedToClient: actionToApply.nextState!.showToClient ? clientId : 1,
    })
    .where(eq(Tracker.id, tracker.id));
  await db
    .update(Tag)
    .set({ currentState: actionToApply.nextState.id })
    .where(eq(Tag.id, tagId));
  await db.insert(Journal).values({
    ofTracker: tracker.id,
    metaData: {
      fieldChanges: [],
      fromState,
      toState: actionToApply.nextState.id,
    } as JournalMetaData,
  });
}

// eslint-disable-next-line prettier/prettier
function toStringValueOfField(fieldValue: string | number | Date) {  // NOSONAR
  if (fieldValue instanceof Date) {
    return fieldValue.toISOString();
  }
  return fieldValue.toString();
}

const createJournalEntries = async (
  fieldsToUpdate: Map<
    string,
    { value: string | number | Date; valueForJournal: string | number | Date }
  >,
  tagId: number
) => {
  const tag = await db.query.Tag.findFirst({
    where: eq(Tag.id, tagId),
    columns: {
      tracker: true,
    },
  });
  if (!tag) {
    // eslint-disable-next-line no-console
    console.warn('tagService:createJournalEntries: cannot find tag');
  }
  const trackerId = tag!.tracker;
  await db.insert(Journal).values({
    ofTracker: trackerId!,
    metaData: {
      fieldChanges: [...fieldsToUpdate.entries()].map((fc) => {
        return {
          fieldName: fc[0],
          newValue: toStringValueOfField(fc[1].valueForJournal),
        } as FieldChange;
      }),
    } as JournalMetaData,
  });
};

async function updateChannelConfig(
  editTagRequest: EditTagRequest,
  fieldsToUpdate: Map<
    string,
    { value: string | number | Date; valueForJournal: string | number | Date }
  >,
  tagToUpdate: TTag
) {
  if (!editTagRequest.channelConfig) {
    return;
  }

  const { channelConfig } = editTagRequest;
  if (channelConfig.ofChannel) {
    const channel = await db.query.Channel.findFirst({
      where: eq(Channel.id, channelConfig.ofChannel),
      columns: {
        id: true,
        name: true,
      },
    });
    if (channel) {
      fieldsToUpdate.set('forChannel', {
        value: channel.id,
        valueForJournal: channel.name,
      });
    } else {
      // eslint-disable-next-line no-console
      console.warn(`cannot find channel with id: ${channelConfig.ofChannel}`);
    }
  }
  if (channelConfig.additionalInfo) {
    fieldsToUpdate.set('additionalInfo', {
      value: channelConfig.additionalInfo,
      valueForJournal: channelConfig.additionalInfo,
    });
  }
  if (channelConfig.mediaTag) {
    fieldsToUpdate.set('mediaTag', {
      value: channelConfig.mediaTag,
      valueForJournal: channelConfig.mediaTag,
    });
  }
  if (channelConfig.pageUrl) {
    await updatePagesMappedToTag(
      channelConfig.pageUrl.map((p) => {
        return { pageUrl: p } as TNewPage;
      }),
      tagToUpdate
    );
  }
  if (channelConfig.products) {
    await db
      .delete(tagProductMap)
      .where(eq(tagProductMap.tagID, editTagRequest.tagId));
    await db.insert(tagProductMap).values(
      channelConfig.products.map((p) => {
        return { tagID: editTagRequest.tagId, productId: p };
      })
    );
  }
  if (channelConfig.productionDate) {
    fieldsToUpdate.set('productionDate', {
      value: channelConfig.productionDate,
      valueForJournal: channelConfig.productionDate,
    });
  }
  if (channelConfig.expiryDate) {
    fieldsToUpdate.set('expiryDate', {
      value: channelConfig.expiryDate,
      valueForJournal: channelConfig.expiryDate,
    });
  }

  const updateEntries: any = {};
  [...fieldsToUpdate.entries()].forEach((e) => {
    updateEntries[e[0]] = e[1].value;
  });

  await db
    .update(Tag)
    .set(updateEntries)
    .where(eq(Tag.id, editTagRequest.tagId));

  await createJournalEntries(fieldsToUpdate, editTagRequest.tagId);
}

export const editTag = async (
  editTagRequest: EditTagRequest,
  superTokenId: string
) => {
  if (editTagRequest.channelConfig?.productionDate) {
    // eslint-disable-next-line no-param-reassign
    editTagRequest.channelConfig.productionDate = new Date(
      editTagRequest.channelConfig.productionDate
    );
  }
  if (editTagRequest.channelConfig?.expiryDate) {
    // eslint-disable-next-line no-param-reassign
    editTagRequest.channelConfig.expiryDate = new Date(
      editTagRequest.channelConfig.expiryDate
    );
  }
  const { userId, clientId } = await getUserAndClientId(superTokenId);
  const tagToUpdate: TTag | undefined = await db.query.Tag.findFirst({
    where: eq(Tag.id, editTagRequest.tagId),
  });
  if (!tagToUpdate) {
    throw new Error(`tag not found with id: ${editTagRequest.tagId}`);
  }

  const fieldsToUpdate = new Map<
    string,
    {
      value: string | number | Date;
      valueForJournal: string | number | Date;
    }
  >();
  if (editTagRequest.campaignName) {
    const campaignId = await getCampaignIdOfExistingCampaignOrPostCreation(
      editTagRequest.campaignName,
      clientId,
      userId
    );
    fieldsToUpdate.set('ofCampaign', {
      value: campaignId,
      valueForJournal: editTagRequest.campaignName,
    });
  }
  await updateChannelConfig(editTagRequest, fieldsToUpdate, tagToUpdate);
  await updateState(
    editTagRequest.tagId,
    editTagRequest.actionToApply,
    clientId
  );
};

/*
  TODO: fix this to partition by ClientId, and fix Schema to support it
 */
export const getTagsForClient = async (superTokenId: string) => {
  const { clientId } = await getUserAndClientId(superTokenId);
  const statesShownToClient = await db.query.State.findMany({
    where:
      clientId === 1
        ? eq(State.showToXerago, true)
        : eq(State.showToClient, true),
  });
  return db.query.Tag.findMany({
    where: inArray(
      Tag.currentState,
      statesShownToClient.map((s) => s.id)
    ),
    with: {
      channel: {
        columns: {
          name: true,
        },
      },
      campaign: {
        columns: {
          name: true,
        },
      },
    },
  }).then((res) => res as unknown as TagTableView[]);
};

export const getTagsByStateId = async (
  stateId: number
): Promise<TagTableView[]> => {
  return db.query.Tag.findMany({
    where: eq(Tag.currentState, stateId),
    with: {
      channel: {
        columns: {
          name: true,
        },
      },
      campaign: {
        columns: {
          name: true,
        },
      },
    },
  }).then((res) => res as unknown as TagTableView[]);
};
