import { db } from '@/libs/DB';
import type { TState } from '@/models/Schema';

export const getAllStates = async (): Promise<TState[]> => {
  return db.query.State.findMany();
};
