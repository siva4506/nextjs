// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { eq, ilike } from 'drizzle-orm';

import type { SearchParams } from '@/common/types';
import { db } from '@/libs/DB';
import type { TCampaign, TNewCampaign } from '@/models/Schema';
import { Campaign } from '@/models/Schema';
import { getClientId } from '@/utils/getClientId';

export const createCampaign = async (
  newCampaigns: TNewCampaign[]
): Promise<TCampaign[]> => {
  return db
    .insert(Campaign)
    .values(newCampaigns)
    .returning()
    .then((res) => res as TCampaign[]);
};

export const findCampaignsByClientId = async (
  searchParams: SearchParams | undefined | null,
  superTokenId: string
): Promise<TCampaign[]> => {
  const clientID = await getClientId(superTokenId);
  return db.query.Campaign.findMany({
    where: eq(Campaign.ofClient, clientID),
    limit: searchParams && searchParams.limit ? searchParams.limit : 999999,
    offset: searchParams && searchParams.offset ? searchParams.offset : 0,
  });
};

export const getCampaignsLikeName = async (
  name: string
): Promise<{ id: number; name: string }[]> => {
  const query = db.query.Campaign.findMany({
    where: ilike(Campaign.name, `%${name}%`),
    columns: {
      name: true,
      id: true,
    },
  });
  // eslint-disable-next-line no-console
  console.log(query.toSQL().sql);
  return query;
};

export const getCampaignByName = async (campaignName: string) => {
  return db.query.Campaign.findFirst({
    where: eq(Campaign.name, campaignName),
  });
};
