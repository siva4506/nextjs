import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TAction } from '@/models/Schema';
import { State } from '@/models/Schema';

export const getApplicableActions = async (
  stateId: number
): Promise<TAction[] | undefined> => {
  const state = await db.query.State.findFirst({
    where: eq(State.id, stateId),
    with: {
      applicableActions: {
        with: {
          action: true,
        },
      },
    },
  });
  return state?.applicableActions.map((aa) => aa.action);
};
