// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TNewProduct, TProduct } from '@/models/Schema';
import { Product } from '@/models/Schema';
import { getUserAndClientId } from '@/services/userService';

export const findProductByClientId = async (
  superTokenId: string
): Promise<TProduct[]> => {
  const { clientId } = await getUserAndClientId(superTokenId);
  if (clientId === 1) {
    return db.query.Product.findMany();
  }
  return db.query.Product.findMany({
    where: eq(Product.ofClient, clientId),
  });
};

export const createProduct = async (
  newProductId: TNewProduct[]
): Promise<TProduct[]> => {
  return db.insert(Product).values(newProductId).returning();
};
