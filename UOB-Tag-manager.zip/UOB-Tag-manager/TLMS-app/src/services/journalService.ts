// import { eq } from 'drizzle-orm';

// import type { JournalOfTag } from '@/common/types';
// import { db } from '@/libs/DB';
// import { Tag } from '@/models/Schema';

// export const getJournalByTagId = async (
//   tagId: number
// ): Promise<JournalOfTag[]> => {
//   return db.query.Tag.findMany({
//     where: eq(Tag.id, tagId),
//     columns: {
//       id: true,
//     },
//     with: {
//       tracker: {
//         columns: {
//           currentState: true,
//         },
//         with: {
//           journalEntries: true,
//         },
//       },
//     },
//   });
// };
