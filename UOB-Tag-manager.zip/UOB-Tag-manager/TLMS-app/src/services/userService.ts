// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import * as console from 'console';
import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TClient } from '@/models/Schema';
import { Client, User } from '@/models/Schema';
import { getClientId } from '@/utils/getClientId';
import { getUserId } from '@/utils/getUserId';

export async function getUserAndClientId(superTokenId: string) {
  const clientId = await getClientId(superTokenId);
  const userId = await getUserId(superTokenId);

  return {
    userId,
    clientId,
  };
}

export async function createUser(email: string, superTokenId: string) {
  const existingUser = await db.query.User.findFirst({
    where: eq(User.email, email),
  });
  if (existingUser) {
    throw new Error('user already exists');
  }

  const existingClient: TClient | undefined = await db.query.Client.findFirst({
    // @ts-ignore
    where: eq(Client.domainName, email.split('@')[1].trim()),
  });
  console.log(`client: ${JSON.stringify(existingClient)}`);
  if (!existingClient) {
    throw new Error("client doesn't exist");
  }
  console.log(`email: ${email}, superTokenId: ${superTokenId}`);

  const createdUser = await db
    .insert(User)
    .values({
      email,
      superTokenId,
      ofClient: existingClient.id,
    })
    .returning();
  // eslint-disable-next-line no-console
  console.log(`created user: ${JSON.stringify(createdUser)}`);

  return createdUser;
}
