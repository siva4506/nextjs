// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TTrigger } from '@/models/Schema';
import { triggers } from '@/models/Schema';
import { getClientId } from '@/utils/getClientId';

export const findTriggersByClientId = async (
  superTokenId: string
): Promise<TTrigger[]> => {
  return db.query.triggers.findMany({
    where: eq(triggers.ofClient, await getClientId(superTokenId)),
  });
};
