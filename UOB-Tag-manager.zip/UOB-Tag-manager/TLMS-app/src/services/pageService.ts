// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { eq, inArray } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TNewPage, TNewTagsToPages, TPage, TTag } from '@/models/Schema';
import { Page, TagsToPages } from '@/models/Schema';

export const createPageToBeTagged = async (
  pages: TNewPage[],
  tag: TTag
): Promise<void> => {
  const existingPages: TPage[] | undefined = await db.query.Page.findMany({
    where: inArray(
      Page.pageUrl,
      pages.map((p) => p.pageUrl)
    ),
  });

  const pagesToBeCreated: TNewPage[] = existingPages
    ? pages.filter(
        (page) => !existingPages.map((p) => p.pageUrl).includes(page.pageUrl)
      )
    : pages;

  if (!pagesToBeCreated) {
    // eslint-disable-next-line no-console
    console.warn(`no pages was created, for req: ${JSON.stringify(pages)}`);
  }
  let createdNewPages: TPage[] | undefined = [];
  if (pagesToBeCreated && pagesToBeCreated.length > 0) {
    createdNewPages = await db
      .insert(Page)
      .values(pagesToBeCreated)
      .returning();
  }
  const pagesToBeLinked = [...createdNewPages, ...existingPages];

  await db.insert(TagsToPages).values(
    pagesToBeLinked.map((p) => {
      return {
        page: p.id,
        tag: tag.id,
      } as TNewTagsToPages;
    })
  );
};

export const updatePagesMappedToTag = async (
  pages: TNewPage[],
  tag: TTag
): Promise<void> => {
  await db.delete(TagsToPages).where(eq(TagsToPages.tag, tag.id));
  await createPageToBeTagged(pages, tag);
};
