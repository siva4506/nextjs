// eslint-disable-next-line import/no-extraneous-dependencies
import 'server-only';

import { inArray } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TChannel } from '@/models/Schema';
import { Channel } from '@/models/Schema';
import { getClientId } from '@/utils/getClientId';

export const findChannelByClientId = async (
  superTokenId: string
): Promise<TChannel[]> => {
  return db.query.Channel.findMany({
    where: inArray(Channel.ofClient, [await getClientId(superTokenId), 1]),
  });
};
