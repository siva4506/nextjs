import { eq } from 'drizzle-orm';

import { db } from '@/libs/DB';
import type { TTracker, TTrackerType } from '@/models/Schema';
import { State, Tracker, TrackerType } from '@/models/Schema';

export const createTracker = async (
  isDraft: boolean,
  clientId: number
): Promise<TTracker> => {
  const trackerType: TTrackerType | undefined =
    await db.query.TrackerType.findFirst({
      where: eq(TrackerType.name, 'default'),
      with: {
        workflow: {
          with: {
            startingState: true,
          },
        },
      },
    });
  if (!trackerType) {
    throw new Error('no default tracker type found');
  }
  // @ts-ignore
  let currentState: number;
  if (isDraft) {
    currentState = await db.query.State.findFirst({
      where: eq(State.name, 'draft'),
    }).then((s) => s!.id);
  } else {
    // @ts-ignore
    currentState = trackerType.workflow.startingState.id;
  }
  const createTrackerStmt = db.insert(Tracker).values({
    assignedToClient: clientId,
    trackerType: trackerType.id,
    currentState,
  });
  console.log(
    `createTrackerStmt: ${JSON.stringify(createTrackerStmt.toSQL())}`
  );
  const createdTracker = await createTrackerStmt.returning().then((r) => r[0]);
  if (!createdTracker) {
    throw new Error('some shit happened, was not able to create a tracker');
  }
  return createdTracker;
};
