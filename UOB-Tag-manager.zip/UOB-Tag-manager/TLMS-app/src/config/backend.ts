import type { RecipeUserId, User } from 'supertokens-node';
// eslint-disable-next-line import/no-extraneous-dependencies
import SuperTokens from 'supertokens-node';
import type { TypePasswordlessEmailDeliveryInput } from 'supertokens-node/lib/build/recipe/passwordless/types';
// eslint-disable-next-line import/no-extraneous-dependencies
import PasswordlessNode from 'supertokens-node/recipe/passwordless';
// eslint-disable-next-line import/no-extraneous-dependencies
import SessionNode from 'supertokens-node/recipe/session';
import type { TypeInput } from 'supertokens-node/types';

import type { CreateUserRequest } from '@/app/api/user/route';

import { appInfo } from './appinfo';

interface EmailSendRequest {
  fromName: string;
  fromEmail: string;
  toName?: string;
  toEmail: string;
  codeLifetime: number;
  otpCode: string;
}

function buildEmailSendRequest(
  input: TypePasswordlessEmailDeliveryInput & {
    tenantId: string;
    userContext: any;
  }
): EmailSendRequest {
  if (!input.userInputCode) {
    throw new Error('otp not present in input');
  }
  // eslint-disable-next-line no-return-assign
  return {
    fromEmail: 'paul@xerago.com',
    fromName: 'paul',
    toEmail: input.email,
    codeLifetime: input.codeLifetime,
    otpCode: input.userInputCode,
  };
}

function isSignUp(response: {
  status: 'OK';
  createdNewRecipeUser: boolean;
  user: User;
  recipeUserId: RecipeUserId;
}) {
  return (
    response.createdNewRecipeUser && response.user.loginMethods.length === 1
  );
}

export const backendConfig = (): TypeInput => {
  return {
    supertokens: {
      // this is the location of the SuperTokens core.
      connectionURI: process.env.SUPER_TOKEN_CORE_URL
        ? process.env.SUPER_TOKEN_CORE_URL
        : 'https://try.supertokens.com',
    },
    appInfo,
    // recipeList contains all the modules that you want to
    // use from SuperTokens. See the full list here: https://supertokens.com/docs/guides
    recipeList: [
      PasswordlessNode.init({
        contactMethod: 'EMAIL',
        flowType: 'USER_INPUT_CODE',
        emailDelivery: {
          override: (originalImplementation) => {
            return {
              ...originalImplementation,
              async sendEmail(input) {
                // eslint-disable-next-line no-console
                console.log(`email input: ${JSON.stringify(input)}`);
                const res = await fetch('http://localhost:3009/send-mail', {
                  method: 'POST',
                  body: JSON.stringify(buildEmailSendRequest(input)),
                  headers: {
                    'Content-Type': 'application/json',
                  },
                });
                // eslint-disable-next-line no-console
                console.debug(`send mail res: ${JSON.stringify(res)}`);
              },
            };
          },
        },
        override: {
          functions: (originalImplementation) => {
            return {
              ...originalImplementation,
              consumeCode: async (input) => {
                const response =
                  await originalImplementation.consumeCode(input);
                if (response.status === 'OK') {
                  const { id, emails, phoneNumbers } = response.user;
                  // eslint-disable-next-line no-console
                  console.log(
                    `user id: ${id}, emails: ${emails[0]}, phoneNums: ${phoneNumbers[0]}`
                  );

                  if (isSignUp(response) && emails && emails[0]) {
                    // eslint-disable-next-line no-console
                    console.log(`user signed-up, ${id}`);
                    await fetch('http://localhost:3000/api/user', {
                      method: 'POST',
                      body: JSON.stringify({
                        superTokenId: id,
                        email: emails[0],
                      } as CreateUserRequest),
                    }).catch((err) => {
                      throw new Error(err);
                    });
                  } else {
                    // eslint-disable-next-line no-console
                    console.log(`user logged in, ${id}`);
                  }
                }
                return response;
              },
            };
          },
        },
      }),
      SessionNode.init(),
    ],
    isInServerlessEnv: true,
  };
};

let initialized = false;

export function ensureSuperTokensInit() {
  if (!initialized) {
    SuperTokens.init(backendConfig());
    initialized = true;
  }
}
