export const appInfo = {
  appName: 'SuperTokens Next.js demo app',
  apiDomain: 'http://localhost:3000',
  websiteDomain: 'http://localhost:3000',
  apiBasePath: '/api/auth',
  websiteBasePath: '/auth',
};
