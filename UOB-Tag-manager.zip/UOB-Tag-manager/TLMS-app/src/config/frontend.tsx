import type { useRouter } from 'next/navigation';
import type { SuperTokensConfig } from 'supertokens-auth-react/lib/build/types';
// eslint-disable-next-line import/no-extraneous-dependencies
import PasswordlessReact from 'supertokens-auth-react/recipe/passwordless';
// eslint-disable-next-line import/no-extraneous-dependencies
import { PasswordlessPreBuiltUI } from 'supertokens-auth-react/recipe/passwordless/prebuiltui';
// eslint-disable-next-line import/no-extraneous-dependencies
import Session from 'supertokens-auth-react/recipe/session';

import { appInfo } from './appinfo';

const routerInfo: { router?: ReturnType<typeof useRouter>; pathName?: string } =
  {};

export function setRouter(
  router: ReturnType<typeof useRouter>,
  pathName: string
) {
  routerInfo.router = router;
  routerInfo.pathName = pathName;
}

export const frontendConfig = (): SuperTokensConfig => {
  return {
    appInfo,
    recipeList: [
      PasswordlessReact.init({
        contactMethod: 'EMAIL',
      }),
      Session.init(),
    ],
    windowHandler: (orig) => {
      return {
        ...orig,
        location: {
          ...orig.location,
          getPathName: () => routerInfo.pathName!,
          assign: (url) => routerInfo.router!.push(url.toString()),
          setHref: (url) => routerInfo.router!.push(url.toString()),
        },
      };
    },
  };
};

// noinspection JSUnusedGlobalSymbols
export const recipeDetails = {
  docsLink: 'https://supertokens.com/docs/passwordless/introduction',
};

export const PreBuiltUIList = [PasswordlessPreBuiltUI];
