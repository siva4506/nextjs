/* eslint-disable no-use-before-define,@typescript-eslint/no-use-before-define */
// noinspection JSUnusedGlobalSymbols

import { relations } from 'drizzle-orm';
import {
  boolean,
  integer,
  jsonb,
  pgSchema,
  serial,
  text,
  timestamp,
  varchar,
} from 'drizzle-orm/pg-core';

export const schema = pgSchema('uob-tag-manager');

export const Client = schema.table('tbl_client', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedON: timestamp('updated_on').defaultNow(),
  name: varchar('name', { length: 64 }),
  domainName: varchar('domain_name', { length: 64 }),
});

export const clientRelation = relations(Client, ({ many }) => ({
  users: many(User),
  channels: many(Channel),
  campaigns: many(Campaign),
  triggers: many(triggers),
  products: many(Product),
  trackers: many(Tracker),
}));

export const User = schema.table('tbl_user', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  lastLoggedIn: timestamp('last_logged_in').defaultNow(),
  superTokenId: varchar('supertoken_id', { length: 36 }).notNull(),
  email: varchar('email', { length: 128 }).notNull(),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  firstName: varchar('first_name', { length: 64 }),
  lastName: varchar('last_name', { length: 64 }),
});

export const userRelation = relations(User, ({ one, many }) => ({
  client: one(Client, {
    fields: [User.ofClient],
    references: [Client.id],
  }),
  campaigns: many(Campaign),
  channels: many(Channel),
  triggers: many(triggers),
  products: many(Product),
}));

export const Channel = schema.table('tbl_channel', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedON: timestamp('updated_on').defaultNow(),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  name: varchar('name', { length: 64 }).notNull(),
  createdBy: integer('created_by')
    .references(() => User.id)
    .notNull(),
});

export const channelRelation = relations(Channel, ({ one }) => ({
  user: one(User, {
    fields: [Channel.createdBy],
    references: [User.id],
  }),
  client: one(Client, {
    fields: [Channel.ofClient],
    references: [Client.id],
  }),
}));

export const Campaign = schema.table('tbl_campaign', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedON: timestamp('updated_on').defaultNow(),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  name: varchar('name', { length: 64 }).notNull(),
  createdBy: integer('created_by')
    .references(() => User.id)
    .notNull(),
});

export const campaignRelation = relations(Campaign, ({ one, many }) => ({
  user: one(User, {
    fields: [Campaign.createdBy],
    references: [User.id],
  }),
  client: one(Client, {
    fields: [Campaign.ofClient],
    references: [Client.id],
  }),
  tags: many(Tag),
}));

export const triggers = schema.table('tbl_trigger', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedON: timestamp('updated_on').defaultNow(),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  name: varchar('name', { length: 64 }).notNull(),
  createdBy: integer('created_by')
    .references(() => User.id)
    .notNull(),
  description: text('description'),
});

export const triggerRelation = relations(triggers, ({ one }) => ({
  user: one(User, {
    fields: [triggers.createdBy],
    references: [User.id],
  }),
  client: one(Client, {
    fields: [triggers.ofClient],
    references: [Client.id],
  }),
}));

export const Product = schema.table('tbl_product', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedON: timestamp('updated_on').defaultNow(),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  name: varchar('name', { length: 64 }).notNull(),
  createdBy: integer('created_by')
    .references(() => User.id)
    .notNull(),
});

export const productRelation = relations(Product, ({ one, many }) => ({
  user: one(User, {
    fields: [Product.createdBy],
    references: [User.id],
  }),
  client: one(Client, {
    fields: [Product.ofClient],
    references: [Client.id],
  }),
  tagProductMap: many(tagProductMap),
}));

export const State = schema.table('tbl_state', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  name: varchar('name', { length: 64 }),
  showToClient: boolean('show_to_client').notNull(),
  showToXerago: boolean('show_to_xerago').notNull(),
});

export const stateRelations = relations(State, ({ many }) => ({
  applicableActions: many(StateActionMap),
}));

export const Tag = schema.table('tbl_tag', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  mediaTag: text('media_tag'),
  productionDate: timestamp('production_date'),
  expiryDate: timestamp('expiry_date'),
  additionalInfo: text('additional_info'),
  ofClient: integer('of_client')
    .references(() => Client.id)
    .notNull(),
  createdBy: integer('created_by')
    .references(() => User.id)
    .notNull(),
  ofCampaign: integer('of_campaign')
    .references(() => Campaign.id)
    .notNull(),
  forChannel: integer('for_channel')
    .references(() => Channel.id)
    .notNull(),
  tracker: integer('tracker').references(() => Tracker.id),
  currentState: integer('state_id').references(() => State.id),
});

export const tagRelation = relations(Tag, ({ one, many }) => ({
  campaign: one(Campaign, {
    fields: [Tag.ofCampaign],
    references: [Campaign.id],
  }),
  channel: one(Channel, {
    fields: [Tag.forChannel],
    references: [Channel.id],
  }),
  currentState: one(State, {
    fields: [Tag.currentState],
    references: [State.id],
  }),
  tagProductMap: many(tagProductMap),
  tracker: one(Tracker, {
    fields: [Tag.tracker],
    references: [Tracker.id],
  }),
  pages: many(TagsToPages),
  ofClient: one(Client, {
    fields: [Tag.ofClient],
    references: [Client.id],
  }),
  createdBy: one(User, {
    fields: [Tag.createdBy],
    references: [User.id],
  }),
}));

export const Page = schema.table('tbl_page', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  pageUrl: text('page_url').notNull(),
  trigger: integer('trigger').references(() => triggers.id),
});

export const pageToBeTaggedRelation = relations(Page, ({ one, many }) => ({
  tagsMapped: many(TagsToPages),
  triggers: one(triggers, {
    fields: [Page.trigger],
    references: [triggers.id],
  }),
}));

export const TagsToPages = schema.table('map_tag__page', {
  tag: integer('tag_id')
    .references(() => Tag.id)
    .notNull(),
  page: integer('page_id')
    .references(() => Page.id)
    .notNull(),
});

export const tagToPageRelation = relations(TagsToPages, ({ one }) => ({
  pageData: one(Page, {
    fields: [TagsToPages.page],
    references: [Page.id],
  }),
  tagData: one(Tag, {
    fields: [TagsToPages.tag],
    references: [Tag.id],
  }),
}));

export const tagProductMap = schema.table('map_tag_product', {
  tagID: integer('tag_id')
    .references(() => Tag.id)
    .notNull(),
  productId: integer('product_id')
    .references(() => Product.id)
    .notNull(),
});

export const tagProductMapRelations = relations(tagProductMap, ({ one }) => ({
  tag: one(Tag, {
    fields: [tagProductMap.tagID],
    references: [Tag.id],
  }),
  product: one(Product, {
    fields: [tagProductMap.productId],
    references: [Product.id],
  }),
}));

export const Action = schema.table('tbl_action', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  name: varchar('name', { length: 64 }),
  nextState: integer('next_state')
    .references(() => State.id)
    .notNull(),
});

export const actionRelations = relations(Action, ({ one }) => ({
  nextState: one(State, {
    fields: [Action.nextState],
    references: [State.id],
    relationName: 'nextAction',
  }),
}));

export const StateActionMap = schema.table('map_state__action', {
  state: integer('state_id')
    .references(() => State.id)
    .notNull(),
  action: integer('action_id')
    .references(() => Action.id)
    .notNull(),
});

export const stateActionMapRelations = relations(StateActionMap, ({ one }) => ({
  state: one(State, {
    fields: [StateActionMap.state],
    references: [State.id],
  }),
  action: one(Action, {
    fields: [StateActionMap.action],
    references: [Action.id],
  }),
}));

export const Workflow = schema.table('tbl_workflow', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  name: varchar('name', { length: 64 }),
  startingState: integer('starting_state')
    .references(() => State.id)
    .notNull(),
});

export const workflowRelations = relations(Workflow, ({ one }) => ({
  startingState: one(State, {
    fields: [Workflow.startingState],
    references: [State.id],
  }),
}));

export const TrackerType = schema.table('tbl_tracker_type', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  name: varchar('name', { length: 64 }),
  workflow: integer('workflow')
    .references(() => Workflow.id)
    .notNull(),
});

export const trackerTypeRelations = relations(TrackerType, ({ one }) => ({
  workflow: one(Workflow, {
    fields: [TrackerType.workflow],
    references: [Workflow.id],
  }),
}));

export const Tracker = schema.table('tbl_tracker', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  trackerType: integer('tracker_type')
    .references(() => TrackerType.id)
    .notNull(),
  currentState: integer('current_state')
    .references(() => State.id)
    .notNull(),
  assignedToClient: integer('assigned_to').references(() => Client.id),
});

export const trackerRelations = relations(Tracker, ({ one, many }) => ({
  trackerType: one(TrackerType, {
    fields: [Tracker.trackerType],
    references: [TrackerType.id],
  }),
  assignedToClient: one(Client, {
    fields: [Tracker.assignedToClient],
    references: [Client.id],
  }),
  journalEntries: many(Journal),
}));

export const Journal = schema.table('tbl_journal', {
  id: serial('id').primaryKey(),
  createdOn: timestamp('created_on').defaultNow(),
  updatedOn: timestamp('updated_on').defaultNow(),
  ofTracker: integer('of_tracker')
    .references(() => Tracker.id)
    .notNull(),
  comment: text('comment'),
  fromState: integer('from_state').references(() => State.id),
  toState: integer('to_state').references(() => State.id),
  metaData: jsonb('meta_data'),
});

export const journalRelations = relations(Journal, ({ one }) => ({
  ofTracker: one(Tracker, {
    fields: [Journal.ofTracker],
    references: [Tracker.id],
  }),
  fromState: one(State, {
    fields: [Journal.fromState],
    references: [State.id],
  }),
  toState: one(State, {
    fields: [Journal.toState],
    references: [State.id],
  }),
}));

export type TClient = typeof Client.$inferSelect;
export type TNewClient = typeof Client.$inferInsert;

export type TUser = typeof User.$inferSelect;
export type TNewUSer = typeof User.$inferInsert;

export type TCampaign = typeof Campaign.$inferSelect;
export type TNewCampaign = typeof Campaign.$inferInsert;

export type TProduct = typeof Product.$inferSelect;
export type TNewProduct = typeof Product.$inferInsert;

export type TTrigger = typeof triggers.$inferSelect;
export type TNewTrigger = typeof triggers.$inferInsert;

export type TChannel = typeof Channel.$inferSelect;
export type NewChannel = typeof Channel.$inferInsert;

export type TTag = typeof Tag.$inferSelect;
export type TNewTag = typeof Tag.$inferInsert;

export type TPage = typeof Page.$inferSelect;
export type TNewPage = typeof Page.$inferInsert;

export type TTagsToPages = typeof TagsToPages.$inferSelect;
export type TNewTagsToPages = typeof TagsToPages.$inferInsert;

export type TWorkflow = typeof Workflow.$inferSelect;
export type TNewWorkFlow = typeof Workflow.$inferInsert;

export type TTrackerType = typeof TrackerType.$inferSelect;
export type TNewTrackerType = typeof TrackerType.$inferInsert;

export type TTracker = typeof Tracker.$inferSelect;
export type TNewTracker = typeof Tracker.$inferInsert;

export type TState = typeof State.$inferSelect;
export type TNewState = typeof State.$inferInsert;

export type TAction = typeof Action.$inferSelect;
export type TNewAction = typeof Action.$inferInsert;

export type TStateActionMap = typeof StateActionMap.$inferSelect;
export type TNewStateActionMap = typeof StateActionMap.$inferInsert;

export type TJournal = typeof Journal.$inferSelect;
export type TNewJournal = typeof Journal.$inferInsert;
