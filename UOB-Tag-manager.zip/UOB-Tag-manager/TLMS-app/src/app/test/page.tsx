// import React from 'react';

// import TestCard from '@/components/TestCard';

// const page = () => {
//   return (
//     <div>
//       <TestCard />
//     </div>
//   );
// };

// export default page;
