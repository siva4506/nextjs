import React from 'react';

import Footer from '@/components/Footer';
import Intro from '@/components/Intro';
import Login from '@/components/Login';

const page = () => {
  return (
    <div>
      <div className="grid grid-cols-2">
        <Intro />
        <Login />
      </div>
      <Footer />
    </div>
  );
};

export default page;
