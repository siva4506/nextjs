import { NextResponse } from 'next/server';

import { createUser } from '@/services/userService';

export interface CreateUserRequest {
  superTokenId: string;
  email: string;
}

export async function POST(request: Request) {
  try {
    const { superTokenId, email } = (await request.json()) as CreateUserRequest;
    await createUser(email, superTokenId);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('some error in creating user', err);
    return NextResponse.json({ status: 'error' }, { status: 500 });
  }

  return NextResponse.json({ status: 'created' }, { status: 200 });
}
