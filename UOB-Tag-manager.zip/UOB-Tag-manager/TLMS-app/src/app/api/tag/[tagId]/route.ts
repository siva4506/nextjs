import { NextResponse } from 'next/server';

import type { TagData } from '@/common/types';
import { findTagById } from '@/services/tagService';

export async function GET(
  _: Request,
  { params }: { params: { tagId: number } }
) {
  const tagData: TagData = await findTagById(params.tagId);
  return NextResponse.json({ status: 'OK', tag: tagData }, { status: 200 });
}

// export async function PUT(request: Request) {
//   const newInfo: EditTagType = await request.json();
//   // eslint-disable-next-line no-console
//   const updatedTag: TTag = await updateTag(newInfo).then(
//     (res) => res[0] as TTag
//   );

//   return NextResponse.json({ tag: updatedTag }, { status: 200 });
// }
