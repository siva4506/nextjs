import { headers } from 'next/headers';
import { NextResponse } from 'next/server';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import type { TagTableView } from '@/services/tagService';
import { findAllTags } from '@/services/tagService';

export async function GET(_: Request) {
  const tags: TagTableView[] = await findAllTags(
    headers().get(SUPER_TOKEN_HEADER)!
  );
  return NextResponse.json({ status: 'OK', tagList: tags }, { status: 200 });
}
