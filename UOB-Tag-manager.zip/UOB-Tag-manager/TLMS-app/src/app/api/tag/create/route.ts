import { headers } from 'next/headers';
import { NextResponse } from 'next/server';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import type { NewTagRequest } from '@/common/types';
import { createTagUsingForm } from '@/services/tagService';

export async function POST(request: Request) {
  const superTokenId = headers().get(SUPER_TOKEN_HEADER)!;

  return request
    .json()
    .then((req) => createTagUsingForm(req as NewTagRequest, superTokenId))
    .then((createdTag) => {
      // eslint-disable-next-line no-console
      console.log(`savedTask: ${JSON.stringify(createdTag)}`);

      return NextResponse.json(
        { status: 'OK', newTag: createdTag },
        { status: 200 }
      );
    })
    .catch((e) => {
      // eslint-disable-next-line no-console
      console.error(e, e.stack);
      return NextResponse.json(
        { status: 'Tag Creation failed', error: e },
        { status: 500 }
      );
    });
}
