import { headers } from 'next/headers';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import type { TCampaign } from '@/models/Schema';
import { findCampaignsByClientId } from '@/services/campaignService';

export async function GET(request: Request): Promise<TCampaign[]> {
  const data = await request.json();
  return findCampaignsByClientId(
    data.campaignName,
    headers().get(SUPER_TOKEN_HEADER)!
  ).then((res) => res);
}
