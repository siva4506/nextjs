import { NextResponse } from 'next/server';

import { getCampaignsLikeName } from '@/services/campaignService';

export async function POST(request: Request) {
  const data = await request.json();
  const campaigns = await getCampaignsLikeName(data.campaignName);
  if (!campaigns) {
    return NextResponse.json({ campaigns: [] }, { status: 200 });
  }
  return NextResponse.json({ campaigns }, { status: 200 });
}
