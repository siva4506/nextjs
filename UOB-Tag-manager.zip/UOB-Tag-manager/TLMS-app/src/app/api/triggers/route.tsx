import { headers } from 'next/headers';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import type { TTrigger } from '@/models/Schema';
import { findTriggersByClientId } from '@/services/triggerServices';

export async function GET(_: Request): Promise<TTrigger[]> {
  return findTriggersByClientId(headers().get(SUPER_TOKEN_HEADER)!);
}
