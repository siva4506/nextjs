import { headers } from 'next/headers';
import { NextResponse } from 'next/server';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import { findProductByClientId } from '@/services/productService';

export async function GET(_: Request) {
  const products = await findProductByClientId(
    headers().get(SUPER_TOKEN_HEADER)!
  );
  return NextResponse.json({ status: 'OK', products }, { status: 200 });
}
