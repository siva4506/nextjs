import { NextResponse } from 'next/server';

import type { TNewProduct } from '@/models/Schema';
import { createProduct } from '@/services/productService';

export async function POST(request: Request) {
  const savedProduct = await request
    .json()
    .then((req) => createProduct(req as TNewProduct[]));

  return NextResponse.json(
    {
      status: 'OK',
      createdProduct: savedProduct,
    },
    { status: 200 }
  );
}
