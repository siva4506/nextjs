import { headers } from 'next/headers';
import { NextResponse } from 'next/server';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import { findChannelByClientId } from '@/services/channelService';

export async function GET(_: Request) {
  const channels = await findChannelByClientId(
    headers().get(SUPER_TOKEN_HEADER)!
  );

  return NextResponse.json({ status: 'OK', channels }, { status: 200 });
}
