import { headers } from 'next/headers';
import React from 'react';

import type { TagData } from '@/common/types';
import TagDetails from '@/components/TagDetails';

const page = async ({ params }: { params: { slug: number } }) => {
  const headersForReq: [string, string][] = [];
  headersForReq.push(['Content-Type', 'application/json']);
  headersForReq.push(['Accept', 'application/json']);
  headers().forEach((value, key) => headersForReq.push([key, value]));
  const tagResponse = await fetch(
    `http://localhost:3000/api/tag/${params.slug}`,
    {
      cache: 'no-cache',
      headers: headersForReq,
    }
  );

  // if (tagResponse.status !== 200)
  //   return (
  //     <Layout>
  //       <p>Could not Get tag with id {params.tagId}</p>
  //     </Layout>
  //   );

  const tagData: { status: string; tag: TagData } = await tagResponse.json();

  return <TagDetails tagData={tagData.tag} />;
};

export default page;
