import React from 'react';

import EditTagForm from '@/components/EditTagForm';
import { findTagById } from '@/services/tagService';

const page = async ({ params }: { params: { tagId: number } }) => {
  const tag = await findTagById(params.tagId);

  return <EditTagForm tagData={tag} />;
};

export default page;
