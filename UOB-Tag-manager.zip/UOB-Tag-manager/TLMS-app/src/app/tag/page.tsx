import { headers } from 'next/headers';
import React from 'react';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import Tag from '@/components/Tag';
import { findAllTags, getTagsByStateId } from '@/services/tagService';

const page = async ({
  searchParams,
}: {
  searchParams?: { state: number | undefined };
}) => {
  const tags = searchParams?.state
    ? await getTagsByStateId(searchParams.state)
    : await findAllTags(headers().get(SUPER_TOKEN_HEADER)!);
  return <Tag params={{ state: searchParams?.state }} tags={tags} />;
};

export default page;
