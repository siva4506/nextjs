import React from 'react';

import NewRequest from '@/components/NewRequest';

const page = () => {
  return <NewRequest />;
};

export default page;
