'use server';

import { revalidatePath } from 'next/cache';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';

import { SUPER_TOKEN_HEADER } from '@/common/constants';
import type { EditTagRequest, NewTagRequest } from '@/common/types';
import { createTagUsingForm, editTag } from '@/services/tagService';

export async function createTagAction(request: NewTagRequest) {
  const superTokenId = headers().get(SUPER_TOKEN_HEADER)!;
  // eslint-disable-next-line no-console
  console.log(`createTagAction request: ${JSON.stringify(request)}`);
  await createTagUsingForm(request, superTokenId);
  redirect('/');
}

export async function updateTagAction(request: EditTagRequest) {
  const superTokenId = headers().get(SUPER_TOKEN_HEADER)!;
  // eslint-disable-next-line no-console
  console.log(`updateTagAction request: ${JSON.stringify(request)}`);
  await editTag(request, superTokenId);
  revalidatePath('/'); // TODO - revalidate current path alone
}
