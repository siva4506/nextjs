export const SUPER_TOKEN_HEADER = 'supertoken-id';
