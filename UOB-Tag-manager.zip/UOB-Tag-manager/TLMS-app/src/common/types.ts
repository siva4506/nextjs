export type SearchParams = {
  limit: number;
  offset: number;
};

export type ChannelConfig = {
  ofChannel: number;
  product: number[];
  mediaTag: string;
  pageUrl: string[];
  productionDate: Date;
  expiryDate: Date;
  additionalInfo: string;
};

export type EditChannelConfig = {
  ofChannel?: number | null | undefined;
  products?: number[] | null | undefined;
  mediaTag?: string | null | undefined;
  pageUrl?: string[] | null | undefined;
  productionDate?: Date | null | undefined;
  expiryDate?: Date | null | undefined;
  additionalInfo?: string | null | undefined;
};

export type NewTagRequest = {
  campaignName: string;
  channelConfig: ChannelConfig[];
  isDraft: boolean;
};

export type EditTagRequest = {
  tagId: number;
  campaignName?: string | null | undefined;
  channelConfig?: EditChannelConfig | null | undefined;
  actionToApply?: number | undefined | null;
};

export type TagData = {
  id: number;
  createdOn: Date | null;
  updatedON: Date | null;
  mediaTag: string | null;
  productionDate: Date | null;
  expiryDate: Date | null;
  additionalInfo: string | null;
  ofCampaign: number;
  forChannel: number;
  tracker: {
    currentState: number;
    journalEntries: {
      id: number;
      createdOn: Date | null;
      updatedOn: Date | null;
      ofTracker: number;
      comment: string | null;
      fromState: number | null;
      toState: number | null;
      metaData: unknown;
    }[];
  };
  pages: {
    pageData: {
      pageUrl: string;
      id: number;
    };
  }[];
  campaign: {
    name: string;
    id: number;
  };
  channel: {
    name: string;
    id: number;
  };
  currentState: {
    applicableActions: {
      action: {
        id: number;
        name: string;
        nextState: {
          id: number;
          name: string;
        };
      };
    }[];
  };
  tagProductMap: {
    product: {
      id: number;
      name: string;
    };
  }[];
};

export type FieldChange = {
  fieldName: string;
  oldValue?: string;
  newValue: string;
};

export type JournalMetaData = {
  fieldChanges?: FieldChange[];
  fromState?: number | null;
  toState?: number | null;
};

export type JournalOfTag = {
  id: number;
  createdOn: Date | null;
  updatedOn: Date | null;
  ofTracker: number;
  comment: string | null;
  fromState: number | null;
  toState: number | null;
  metaData: unknown;
};
