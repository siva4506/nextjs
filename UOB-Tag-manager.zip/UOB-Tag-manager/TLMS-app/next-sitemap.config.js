/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://example.com', // FIXME: Change to the production URL
  generateRobotsTxt: true,
};
