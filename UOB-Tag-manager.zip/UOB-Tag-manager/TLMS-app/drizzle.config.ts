import type { Config } from "drizzle-kit";

export default {
  schema: "./src/models/Schema.ts",
  out: "./drizzle",
  driver: "pg",
  dbCredentials: {
    host: "127.0.0.1",
    user: "postgres",
    password: "password",
    database: "postgres",
  },
} satisfies Config;
